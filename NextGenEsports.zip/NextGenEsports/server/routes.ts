import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getSession, isAdminAuthenticated, hashPassword, verifyPassword } from "./auth";
import { 
  insertTeamSchema, 
  insertTournamentSchema, 
  insertSupportTicketSchema,
  insertTimeSlotSchema,
  insertTournamentRulesSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(getSession());

  // Initialize default admin if none exists
  const existingAdmin = await storage.getAdminByUsername("admin");
  if (!existingAdmin) {
    await storage.createAdmin({
      username: "admin",
      password: await hashPassword("7204952616@Diku"),
    });
  }

  // Admin authentication routes
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const admin = await storage.getAdminByUsername(username);
      if (!admin || !await verifyPassword(password, admin.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.adminId = admin.id;
      res.json({ message: "Login successful" });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Failed to login" });
    }
  });

  app.post("/api/admin/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  app.get("/api/admin/check", isAdminAuthenticated, (req, res) => {
    res.json({ authenticated: true });
  });

  // Team registration routes
  app.post("/api/teams", async (req, res) => {
    try {
      const teamData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(teamData);
      res.status(201).json(team);
    } catch (error: any) {
      console.error("Create team error:", error);
      res.status(400).json({ message: error.message || "Failed to create team" });
    }
  });

  app.get("/api/teams", isAdminAuthenticated, async (req, res) => {
    try {
      const teams = await storage.getTeams();
      res.json(teams);
    } catch (error) {
      console.error("Get teams error:", error);
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });

  app.get("/api/teams/pending", isAdminAuthenticated, async (req, res) => {
    try {
      const teams = await storage.getPendingTeams();
      res.json(teams);
    } catch (error) {
      console.error("Get pending teams error:", error);
      res.status(500).json({ message: "Failed to fetch pending teams" });
    }
  });

  app.get("/api/teams/approved", async (req, res) => {
    try {
      const teams = await storage.getApprovedTeams();
      res.json(teams);
    } catch (error) {
      console.error("Get approved teams error:", error);
      res.status(500).json({ message: "Failed to fetch approved teams" });
    }
  });

  app.put("/api/teams/:id/status", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!["pending", "approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      await storage.updateTeamStatus(id, status);
      res.json({ message: "Team status updated" });
    } catch (error) {
      console.error("Update team status error:", error);
      res.status(500).json({ message: "Failed to update team status" });
    }
  });

  app.delete("/api/teams/:id", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTeam(id);
      res.json({ message: "Team deleted" });
    } catch (error) {
      console.error("Delete team error:", error);
      res.status(500).json({ message: "Failed to delete team" });
    }
  });

  // Tournament routes
  app.get("/api/tournaments", async (req, res) => {
    try {
      const tournaments = await storage.getTournaments();
      res.json(tournaments);
    } catch (error) {
      console.error("Get tournaments error:", error);
      res.status(500).json({ message: "Failed to fetch tournaments" });
    }
  });

  app.post("/api/tournaments", isAdminAuthenticated, async (req, res) => {
    try {
      const tournamentData = insertTournamentSchema.parse(req.body);
      const tournament = await storage.createTournament(tournamentData);
      res.status(201).json(tournament);
    } catch (error: any) {
      console.error("Create tournament error:", error);
      res.status(400).json({ message: error.message || "Failed to create tournament" });
    }
  });

  app.put("/api/tournaments/:id", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = insertTournamentSchema.partial().parse(req.body);
      await storage.updateTournament(id, updates);
      res.json({ message: "Tournament updated" });
    } catch (error: any) {
      console.error("Update tournament error:", error);
      res.status(400).json({ message: error.message || "Failed to update tournament" });
    }
  });

  app.delete("/api/tournaments/:id", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTournament(id);
      res.json({ message: "Tournament deleted" });
    } catch (error) {
      console.error("Delete tournament error:", error);
      res.status(500).json({ message: "Failed to delete tournament" });
    }
  });

  // Support ticket routes
  app.post("/api/support", async (req, res) => {
    try {
      const ticketData = insertSupportTicketSchema.parse(req.body);
      const ticket = await storage.createSupportTicket(ticketData);
      res.status(201).json(ticket);
    } catch (error: any) {
      console.error("Create support ticket error:", error);
      res.status(400).json({ message: error.message || "Failed to create support ticket" });
    }
  });

  app.get("/api/support", isAdminAuthenticated, async (req, res) => {
    try {
      const tickets = await storage.getSupportTickets();
      res.json(tickets);
    } catch (error) {
      console.error("Get support tickets error:", error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  app.put("/api/support/:id/status", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status, adminReply } = req.body;
      
      if (!["open", "resolved", "closed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      await storage.updateSupportTicketStatus(id, status, adminReply);
      res.json({ message: "Support ticket updated" });
    } catch (error) {
      console.error("Update support ticket error:", error);
      res.status(500).json({ message: "Failed to update support ticket" });
    }
  });

  // Time slots routes
  app.get("/api/timeslots", isAdminAuthenticated, async (req, res) => {
    try {
      const timeSlots = await storage.getTimeSlots();
      res.json(timeSlots);
    } catch (error) {
      console.error("Get time slots error:", error);
      res.status(500).json({ message: "Failed to fetch time slots" });
    }
  });

  app.post("/api/timeslots", isAdminAuthenticated, async (req, res) => {
    try {
      const slotData = insertTimeSlotSchema.parse(req.body);
      const slot = await storage.createTimeSlot(slotData);
      res.status(201).json(slot);
    } catch (error: any) {
      console.error("Create time slot error:", error);
      res.status(400).json({ message: error.message || "Failed to create time slot" });
    }
  });

  app.put("/api/timeslots/:id/teams", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { teamIds } = req.body;
      await storage.updateTimeSlotTeams(id, teamIds);
      res.json({ message: "Time slot teams updated" });
    } catch (error) {
      console.error("Update time slot teams error:", error);
      res.status(500).json({ message: "Failed to update time slot teams" });
    }
  });

  app.delete("/api/timeslots/:id", isAdminAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTimeSlot(id);
      res.json({ message: "Time slot deleted" });
    } catch (error) {
      console.error("Delete time slot error:", error);
      res.status(500).json({ message: "Failed to delete time slot" });
    }
  });

  // Tournament rules routes
  app.get("/api/rules", async (req, res) => {
    try {
      const rules = await storage.getTournamentRules();
      res.json(rules || {
        general: "All participants must use their own mobile phones and internet connection\nTeam registration must be completed before the deadline\nOnly registered teams will be eligible to participate\nCheating or use of hacks will result in immediate disqualification\nAll matches must be played at the scheduled time slots",
        devices: "Mobile Device: Android 4.1+ or iOS 9.0+\nRAM: Minimum 3GB recommended\nInternet: Stable 4G/WiFi connection required\nBattery: Ensure full charge before matches\nHeadphones: Gaming headphones recommended",
        fairPlay: "Respectful communication with all participants\nNo toxic behavior or harassment will be tolerated\nReport any suspicious activity to tournament officials\nScreenshots of results may be required for verification"
      });
    } catch (error) {
      console.error("Get rules error:", error);
      res.status(500).json({ message: "Failed to fetch rules" });
    }
  });

  app.put("/api/rules", isAdminAuthenticated, async (req, res) => {
    try {
      const rulesData = insertTournamentRulesSchema.parse(req.body);
      await storage.updateTournamentRules(rulesData);
      res.json({ message: "Rules updated" });
    } catch (error: any) {
      console.error("Update rules error:", error);
      res.status(400).json({ message: error.message || "Failed to update rules" });
    }
  });

  // Stats route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
