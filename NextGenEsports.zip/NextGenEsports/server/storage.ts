import {
  teams,
  tournaments,
  supportTickets,
  timeSlots,
  tournamentRules,
  admins,
  type Team,
  type InsertTeam,
  type Tournament,
  type InsertTournament,
  type SupportTicket,
  type InsertSupportTicket,
  type TimeSlot,
  type InsertTimeSlot,
  type TournamentRules,
  type InsertTournamentRules,
  type Admin,
  type InsertAdmin,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  getTeams(): Promise<Team[]>;
  getTeam(id: string): Promise<Team | undefined>;
  updateTeamStatus(id: string, status: "pending" | "approved" | "rejected"): Promise<void>;
  deleteTeam(id: string): Promise<void>;
  getPendingTeams(): Promise<Team[]>;
  getApprovedTeams(): Promise<Team[]>;

  // Tournament operations
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  getTournaments(): Promise<Tournament[]>;
  getTournament(id: string): Promise<Tournament | undefined>;
  updateTournament(id: string, updates: Partial<InsertTournament>): Promise<void>;
  deleteTournament(id: string): Promise<void>;

  // Support ticket operations
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getSupportTickets(): Promise<SupportTicket[]>;
  getSupportTicket(id: string): Promise<SupportTicket | undefined>;
  updateSupportTicketStatus(id: string, status: "open" | "resolved" | "closed", adminReply?: string): Promise<void>;

  // Time slot operations
  createTimeSlot(slot: InsertTimeSlot): Promise<TimeSlot>;
  getTimeSlots(): Promise<TimeSlot[]>;
  getTimeSlot(id: string): Promise<TimeSlot | undefined>;
  updateTimeSlotTeams(id: string, teamIds: string[]): Promise<void>;
  deleteTimeSlot(id: string): Promise<void>;

  // Tournament rules operations
  getTournamentRules(): Promise<TournamentRules | undefined>;
  updateTournamentRules(rules: InsertTournamentRules): Promise<void>;

  // Admin operations
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;

  // Stats
  getStats(): Promise<{
    pendingRegistrations: number;
    activeTeams: number;
    supportTickets: number;
    tournaments: number;
    totalPlayers: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Team operations
  async createTeam(teamData: InsertTeam): Promise<Team> {
    const [team] = await db
      .insert(teams)
      .values(teamData)
      .returning();
    return team;
  }

  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams).orderBy(desc(teams.createdAt));
  }

  async getTeam(id: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team;
  }

  async updateTeamStatus(id: string, status: "pending" | "approved" | "rejected"): Promise<void> {
    await db
      .update(teams)
      .set({ status, updatedAt: new Date() })
      .where(eq(teams.id, id));
  }

  async deleteTeam(id: string): Promise<void> {
    await db.delete(teams).where(eq(teams.id, id));
  }

  async getPendingTeams(): Promise<Team[]> {
    return await db
      .select()
      .from(teams)
      .where(eq(teams.status, "pending"))
      .orderBy(desc(teams.createdAt));
  }

  async getApprovedTeams(): Promise<Team[]> {
    return await db
      .select()
      .from(teams)
      .where(eq(teams.status, "approved"))
      .orderBy(desc(teams.createdAt));
  }

  // Tournament operations
  async createTournament(tournamentData: InsertTournament): Promise<Tournament> {
    const [tournament] = await db
      .insert(tournaments)
      .values(tournamentData)
      .returning();
    return tournament;
  }

  async getTournaments(): Promise<Tournament[]> {
    return await db.select().from(tournaments).orderBy(desc(tournaments.createdAt));
  }

  async getTournament(id: string): Promise<Tournament | undefined> {
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.id, id));
    return tournament;
  }

  async updateTournament(id: string, updates: Partial<InsertTournament>): Promise<void> {
    await db
      .update(tournaments)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tournaments.id, id));
  }

  async deleteTournament(id: string): Promise<void> {
    await db.delete(tournaments).where(eq(tournaments.id, id));
  }

  // Support ticket operations
  async createSupportTicket(ticketData: InsertSupportTicket): Promise<SupportTicket> {
    const [ticket] = await db
      .insert(supportTickets)
      .values(ticketData)
      .returning();
    return ticket;
  }

  async getSupportTickets(): Promise<SupportTicket[]> {
    return await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
  }

  async getSupportTicket(id: string): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets).where(eq(supportTickets.id, id));
    return ticket;
  }

  async updateSupportTicketStatus(id: string, status: "open" | "resolved" | "closed", adminReply?: string): Promise<void> {
    const updates: any = { status, updatedAt: new Date() };
    if (adminReply) {
      updates.adminReply = adminReply;
    }
    await db
      .update(supportTickets)
      .set(updates)
      .where(eq(supportTickets.id, id));
  }

  // Time slot operations
  async createTimeSlot(slotData: InsertTimeSlot): Promise<TimeSlot> {
    const [slot] = await db
      .insert(timeSlots)
      .values(slotData)
      .returning();
    return slot;
  }

  async getTimeSlots(): Promise<TimeSlot[]> {
    return await db.select().from(timeSlots).orderBy(timeSlots.date, timeSlots.startTime);
  }

  async getTimeSlot(id: string): Promise<TimeSlot | undefined> {
    const [slot] = await db.select().from(timeSlots).where(eq(timeSlots.id, id));
    return slot;
  }

  async updateTimeSlotTeams(id: string, teamIds: string[]): Promise<void> {
    await db
      .update(timeSlots)
      .set({ assignedTeams: teamIds })
      .where(eq(timeSlots.id, id));
  }

  async deleteTimeSlot(id: string): Promise<void> {
    await db.delete(timeSlots).where(eq(timeSlots.id, id));
  }

  // Tournament rules operations
  async getTournamentRules(): Promise<TournamentRules | undefined> {
    const [rules] = await db.select().from(tournamentRules).limit(1);
    return rules;
  }

  async updateTournamentRules(rulesData: InsertTournamentRules): Promise<void> {
    const existingRules = await this.getTournamentRules();
    
    if (existingRules) {
      await db
        .update(tournamentRules)
        .set({ ...rulesData, updatedAt: new Date() })
        .where(eq(tournamentRules.id, existingRules.id));
    } else {
      await db.insert(tournamentRules).values(rulesData);
    }
  }

  // Admin operations
  async createAdmin(adminData: InsertAdmin): Promise<Admin> {
    const [admin] = await db
      .insert(admins)
      .values(adminData)
      .returning();
    return admin;
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.username, username));
    return admin;
  }

  // Stats
  async getStats(): Promise<{
    pendingRegistrations: number;
    activeTeams: number;
    supportTickets: number;
    tournaments: number;
    totalPlayers: number;
  }> {
    const [pendingCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(teams)
      .where(eq(teams.status, "pending"));

    const [activeCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(teams)
      .where(eq(teams.status, "approved"));

    const [ticketCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(supportTickets)
      .where(eq(supportTickets.status, "open"));

    const [tournamentCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(tournaments);

    const approvedTeams = await db
      .select({ size: teams.size })
      .from(teams)
      .where(eq(teams.status, "approved"));

    const totalPlayers = approvedTeams.reduce((sum, team) => sum + team.size, 0);

    return {
      pendingRegistrations: pendingCount.count,
      activeTeams: activeCount.count,
      supportTickets: ticketCount.count,
      tournaments: tournamentCount.count,
      totalPlayers,
    };
  }
}

export const storage = new DatabaseStorage();
