import { sql } from "drizzle-orm";
import { 
  pgTable, 
  text, 
  varchar, 
  timestamp, 
  uuid, 
  integer, 
  jsonb,
  pgEnum,
  boolean,
  index
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for admin authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Admin users table
export const admins = pgTable("admins", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Enums
export const gameEnum = pgEnum("game", ["freefire", "bgmi"]);
export const registrationStatusEnum = pgEnum("registration_status", ["pending", "approved", "rejected"]);
export const supportStatusEnum = pgEnum("support_status", ["open", "resolved", "closed"]);
export const tournamentStatusEnum = pgEnum("tournament_status", ["draft", "registration_open", "registration_closed", "active", "completed"]);

// Teams table
export const teams = pgTable("teams", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  game: gameEnum("game").notNull(),
  leaderName: varchar("leader_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  size: integer("size").notNull(),
  members: jsonb("members").notNull(), // Array of {name: string, gameId: string}
  status: registrationStatusEnum("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tournaments table
export const tournaments = pgTable("tournaments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 200 }).notNull(),
  description: text("description"),
  game: gameEnum("game").notNull(),
  maxTeams: integer("max_teams").default(64),
  registeredTeams: integer("registered_teams").default(0),
  status: tournamentStatusEnum("status").default("draft").notNull(),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Support tickets table
export const supportTickets = pgTable("support_tickets", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull(),
  description: text("description").notNull(),
  status: supportStatusEnum("status").default("open").notNull(),
  adminReply: text("admin_reply"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Time slots table
export const timeSlots = pgTable("time_slots", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  tournamentId: uuid("tournament_id").references(() => tournaments.id, { onDelete: "cascade" }),
  date: timestamp("date").notNull(),
  startTime: varchar("start_time", { length: 10 }).notNull(), // "10:00"
  endTime: varchar("end_time", { length: 10 }).notNull(), // "11:00"
  maxTeams: integer("max_teams").default(8),
  assignedTeams: jsonb("assigned_teams").default([]), // Array of team IDs
  createdAt: timestamp("created_at").defaultNow(),
});

// Tournament rules table
export const tournamentRules = pgTable("tournament_rules", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  general: text("general").notNull(),
  devices: text("devices").notNull(),
  fairPlay: text("fair_play").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const tournamentsRelations = relations(tournaments, ({ many }) => ({
  timeSlots: many(timeSlots),
}));

export const timeSlotsRelations = relations(timeSlots, ({ one }) => ({
  tournament: one(tournaments, {
    fields: [timeSlots.tournamentId],
    references: [tournaments.id],
  }),
}));

// Insert schemas
export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  status: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  members: z.array(z.object({
    name: z.string().min(1, "Player name is required"),
    gameId: z.string().min(1, "Game ID is required"),
  })).min(1, "At least one team member is required"),
});

export const insertTournamentSchema = createInsertSchema(tournaments).omit({
  id: true,
  registeredTeams: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  status: true,
  adminReply: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTimeSlotSchema = createInsertSchema(timeSlots).omit({
  id: true,
  assignedTeams: true,
  createdAt: true,
});

export const insertTournamentRulesSchema = createInsertSchema(tournamentRules).omit({
  id: true,
  updatedAt: true,
});

export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Tournament = typeof tournaments.$inferSelect;
export type InsertTournament = z.infer<typeof insertTournamentSchema>;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
export type TimeSlot = typeof timeSlots.$inferSelect;
export type InsertTimeSlot = z.infer<typeof insertTimeSlotSchema>;
export type TournamentRules = typeof tournamentRules.$inferSelect;
export type InsertTournamentRules = z.infer<typeof insertTournamentRulesSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
