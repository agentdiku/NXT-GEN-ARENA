import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gavel, Smartphone, Handshake, Shield } from "lucide-react";
import { Link } from "wouter";

export default function Rules() {
  const { data: rules, isLoading } = useQuery({
    queryKey: ["/api/rules"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading tournament rules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="font-gaming text-3xl font-bold mb-4">Tournament Rules & Guidelines</h1>
        <p className="text-muted-foreground">Please read carefully before participating</p>
      </div>

      <Card className="gaming-glow">
        <CardContent className="p-6 md:p-8">
          <div className="space-y-8">
            {/* General Rules */}
            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center text-primary">
                <Gavel className="mr-3" />
                General Rules
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <div className="whitespace-pre-wrap text-muted-foreground" data-testid="general-rules">
                  {rules?.general || "Loading rules..."}
                </div>
              </div>
            </div>

            {/* Device Requirements */}
            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center text-secondary">
                <Smartphone className="mr-3" />
                Device Requirements
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <div className="whitespace-pre-wrap text-muted-foreground" data-testid="device-requirements">
                  {rules?.devices || "Loading device requirements..."}
                </div>
              </div>
            </div>

            {/* Fair Play Policy */}
            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center text-accent">
                <Handshake className="mr-3" />
                Fair Play Policy
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <div className="whitespace-pre-wrap text-muted-foreground" data-testid="fair-play-policy">
                  {rules?.fairPlay || "Loading fair play policy..."}
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-primary/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 text-primary flex items-center">
                <Shield className="mr-2 h-5 w-5" />
                Need Help?
              </h4>
              <p className="text-sm text-muted-foreground">
                For any questions about tournament rules, contact our support team through the{" "}
                <Link href="/support" className="text-primary hover:underline" data-testid="link-support">
                  support section
                </Link>
                .
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Privacy Policy Link */}
      <div className="text-center">
        <Link href="/privacy">
          <button className="bg-muted text-muted-foreground px-6 py-3 rounded-lg hover:bg-muted/80 transition-colors" data-testid="button-privacy-policy">
            <Shield className="mr-2 h-4 w-4 inline" />
            View Privacy Policy
          </button>
        </Link>
      </div>
    </div>
  );
}
