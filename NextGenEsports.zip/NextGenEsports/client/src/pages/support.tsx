import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Headset, HelpCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const supportSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Valid email is required"),
  category: z.string().min(1, "Please select a category"),
  subject: z.string().min(5, "Subject must be at least 5 characters"),
  description: z.string().min(10, "Please provide more details"),
});

type SupportFormData = z.infer<typeof supportSchema>;

const faqs = [
  {
    question: "How do I register my team?",
    answer: "Navigate to the Tournament section and fill out the registration form with your team details. Make sure all information is accurate before submitting.",
  },
  {
    question: "What happens if my internet disconnects during a match?",
    answer: "Please reconnect as quickly as possible. Contact support immediately if you experience technical issues. Repeated disconnections may affect your team's standing.",
  },
  {
    question: "How are time slots assigned?",
    answer: "Time slots are assigned by tournament admins based on registration order and team preferences. You'll receive an email confirmation with your match schedule.",
  },
  {
    question: "What games are supported?",
    answer: "Currently we support Free Fire and BGMI tournaments. More games may be added in the future based on community demand.",
  },
  {
    question: "How do I know if my registration is approved?",
    answer: "You will receive an email notification once your registration is reviewed by our admin team. You can also check the status in your registration confirmation email.",
  },
];

export default function Support() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const { toast } = useToast();

  const form = useForm<SupportFormData>({
    resolver: zodResolver(supportSchema),
    defaultValues: {
      name: "",
      email: "",
      category: "",
      subject: "",
      description: "",
    },
  });

  const supportMutation = useMutation({
    mutationFn: async (data: SupportFormData) => {
      return await apiRequest("POST", "/api/support", data);
    },
    onSuccess: () => {
      toast({
        title: "Support Ticket Submitted!",
        description: "We will respond within 24 hours. Check your email for updates.",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit support ticket. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SupportFormData) => {
    supportMutation.mutate(data);
  };

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="font-gaming text-3xl font-bold mb-4">Support Center</h1>
        <p className="text-muted-foreground">Get help with tournaments, registration, and technical issues</p>
      </div>

      {/* Support Ticket Form */}
      <Card className="gaming-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Headset className="mr-3 text-primary" />
            Submit Support Ticket
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your name" 
                          className="neon-border"
                          data-testid="input-support-name"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address *</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="your@email.com" 
                          className="neon-border"
                          data-testid="input-support-email"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="neon-border" data-testid="select-support-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="registration">Registration Issues</SelectItem>
                        <SelectItem value="technical">Technical Problems</SelectItem>
                        <SelectItem value="tournament">Tournament Questions</SelectItem>
                        <SelectItem value="payment">Payment/Prize Issues</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Brief description of your issue" 
                        className="neon-border"
                        data-testid="input-support-subject"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description *</FormLabel>
                    <FormControl>
                      <Textarea 
                        rows={5} 
                        placeholder="Please provide detailed information about your issue..." 
                        className="neon-border resize-none"
                        data-testid="textarea-support-description"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="gaming-glow" 
                disabled={supportMutation.isPending}
                data-testid="button-submit-support"
              >
                {supportMutation.isPending ? (
                  "Submitting..."
                ) : (
                  <>
                    <Headset className="mr-2 h-4 w-4" />
                    Submit Ticket
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card className="gaming-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <HelpCircle className="mr-3 text-secondary" />
            Frequently Asked Questions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-border rounded-lg">
                <button
                  className="w-full px-4 py-3 text-left flex items-center justify-between hover:bg-muted/20 transition-colors rounded-lg"
                  onClick={() => toggleFaq(index)}
                  data-testid={`button-faq-${index}`}
                >
                  <span className="font-medium">{faq.question}</span>
                  {openFaq === index ? (
                    <ChevronUp className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="px-4 pb-4 text-muted-foreground" data-testid={`faq-answer-${index}`}>
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
