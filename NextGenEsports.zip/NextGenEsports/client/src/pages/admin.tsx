import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  LogIn,
  LogOut,
  UserCheck,
  Users,
  Headset,
  Trophy,
  Gavel,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Plus,
  Save,
  Reply,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const tournamentSchema = z.object({
  name: z.string().min(3, "Tournament name must be at least 3 characters"),
  description: z.string().optional(),
  game: z.enum(["freefire", "bgmi"]),
  maxTeams: z.coerce.number().min(1).max(128).default(64),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

const timeSlotSchema = z.object({
  tournamentId: z.string().optional(),
  date: z.string().min(1, "Date is required"),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  maxTeams: z.coerce.number().min(1).max(16).default(8),
});

const rulesSchema = z.object({
  general: z.string().min(10, "General rules must be at least 10 characters"),
  devices: z
    .string()
    .min(10, "Device requirements must be at least 10 characters"),
  fairPlay: z
    .string()
    .min(10, "Fair play policy must be at least 10 characters"),
});

type LoginFormData = z.infer<typeof loginSchema>;
type TournamentFormData = z.infer<typeof tournamentSchema>;
type TimeSlotFormData = z.infer<typeof timeSlotSchema>;
type RulesFormData = z.infer<typeof rulesSchema>;

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState("registrations");
  const [selectedTeam, setSelectedTeam] = useState<any>(null);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [selectedSlot, setSelectedSlot] = useState<any>(null);
  const [selectedTeamsForSlot, setSelectedTeamsForSlot] = useState<string[]>(
    [],
  );
  const [replyText, setReplyText] = useState("");
  const { toast } = useToast();

  // Check authentication status
  const { data: authCheck, isLoading: authLoading } = useQuery({
    queryKey: ["/api/admin/check"],
    retry: false,
  });

  useEffect(() => {
    if (authCheck) {
      setIsAuthenticated(true);
    }
  }, [authCheck]);

  // Login form
  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (data: LoginFormData) => {
      return await apiRequest("POST", "/api/admin/login", data);
    },
    onSuccess: () => {
      setIsAuthenticated(true);
      toast({
        title: "Login Successful",
        description: "Welcome to the admin panel!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/check"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/logout", {});
    },
    onSuccess: () => {
      setIsAuthenticated(false);
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully.",
      });
      queryClient.clear();
    },
  });

  // Data queries
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  const { data: teams } = useQuery({
    queryKey: ["/api/teams"],
    enabled: isAuthenticated,
  });

  const { data: pendingTeams } = useQuery({
    queryKey: ["/api/teams/pending"],
    enabled: isAuthenticated,
  });

  const { data: supportTickets } = useQuery({
    queryKey: ["/api/support"],
    enabled: isAuthenticated,
  });

  const { data: approvedTeams } = useQuery({
    queryKey: ["/api/teams/approved"],
    enabled: isAuthenticated,
  });

  const { data: tournaments } = useQuery({
    queryKey: ["/api/tournaments"],
    enabled: isAuthenticated,
  });

  const { data: timeSlots } = useQuery({
    queryKey: ["/api/timeslots"],
    enabled: isAuthenticated,
  });

  const { data: rules } = useQuery({
    queryKey: ["/api/rules"],
    enabled: isAuthenticated,
  });

  // Team status mutation
  const updateTeamStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return await apiRequest("PUT", `/api/teams/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Team Status Updated",
        description: "The team status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.reload();
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update team status",
        variant: "destructive",
      });
    },
  });

  // Delete team mutation
  const deleteTeamMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/teams/${id}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Team Deleted",
        description: "The team has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete team",
        variant: "destructive",
      });
    },
  });

  // Support ticket mutation
  const updateTicketMutation = useMutation({
    mutationFn: async ({
      id,
      status,
      adminReply,
    }: {
      id: string;
      status: string;
      adminReply?: string;
    }) => {
      return await apiRequest("PUT", `/api/support/${id}/status`, {
        status,
        adminReply,
      });
    },
    onSuccess: () => {
      toast({
        title: "Ticket Updated",
        description: "Support ticket has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/support"] });
      setSelectedTicket(null);
      setReplyText("");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update ticket",
        variant: "destructive",
      });
    },
  });

  // Tournament form and mutations
  const tournamentForm = useForm<TournamentFormData>({
    resolver: zodResolver(tournamentSchema),
    defaultValues: {
      name: "",
      description: "",
      game: undefined,
      maxTeams: 64,
      startDate: "",
      endDate: "",
    },
  });

  const createTournamentMutation = useMutation({
    mutationFn: async (data: TournamentFormData) => {
      return await apiRequest("POST", "/api/tournaments", data);
    },
    onSuccess: () => {
      toast({
        title: "Tournament Created",
        description: "New tournament has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      tournamentForm.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create tournament",
        variant: "destructive",
      });
    },
  });

  const deleteTournamentMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/tournaments/${id}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Tournament Deleted",
        description: "Tournament has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete tournament",
        variant: "destructive",
      });
    },
  });

  // Time slot form and mutations
  const timeSlotForm = useForm<TimeSlotFormData>({
    resolver: zodResolver(timeSlotSchema),
    defaultValues: {
      tournamentId: "",
      date: "",
      startTime: "",
      endTime: "",
      maxTeams: 8,
    },
  });

  const createTimeSlotMutation = useMutation({
    mutationFn: async (data: TimeSlotFormData) => {
      const payload = {
        ...data,
        date: new Date(data.date).toISOString(),
      };
      return await apiRequest("POST", "/api/timeslots", payload);
    },
    onSuccess: () => {
      toast({
        title: "Time Slot Created",
        description: "New time slot has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/timeslots"] });
      timeSlotForm.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create time slot",
        variant: "destructive",
      });
    },
  });

  const deleteTimeSlotMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/timeslots/${id}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Time Slot Deleted",
        description: "Time slot has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/timeslots"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete time slot",
        variant: "destructive",
      });
    },
  });

  const assignTeamsToSlotMutation = useMutation({
    mutationFn: async ({
      slotId,
      teamIds,
    }: {
      slotId: string;
      teamIds: string[];
    }) => {
      return await apiRequest("PUT", `/api/timeslots/${slotId}/teams`, {
        teamIds,
      });
    },
    onSuccess: () => {
      toast({
        title: "Teams Assigned",
        description: "Teams have been assigned to the time slot successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/timeslots"] });
      setSelectedSlot(null);
      setSelectedTeamsForSlot([]);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Assignment Failed",
        description: error.message || "Failed to assign teams to slot",
        variant: "destructive",
      });
    },
  });

  // Rules form and mutation
  const rulesForm = useForm<RulesFormData>({
    resolver: zodResolver(rulesSchema),
    defaultValues: {
      general: "",
      devices: "",
      fairPlay: "",
    },
  });

  useEffect(() => {
    if (rules) {
      rulesForm.reset({
        general: rules.general || "",
        devices: rules.devices || "",
        fairPlay: rules.fairPlay || "",
      });
    }
  }, [rules, rulesForm]);

  const updateRulesMutation = useMutation({
    mutationFn: async (data: RulesFormData) => {
      return await apiRequest("PUT", "/api/rules", data);
    },
    onSuccess: () => {
      toast({
        title: "Rules Updated",
        description: "Tournament rules have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/rules"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        setIsAuthenticated(false);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update rules",
        variant: "destructive",
      });
    },
  });

  const onLogin = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  const onLogout = () => {
    logoutMutation.mutate();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge
            variant="outline"
            className="text-orange-400 border-orange-400"
          >
            Pending
          </Badge>
        );
      case "approved":
        return (
          <Badge variant="outline" className="text-green-400 border-green-400">
            Approved
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="text-red-400 border-red-400">
            Rejected
          </Badge>
        );
      case "open":
        return (
          <Badge
            variant="outline"
            className="text-orange-400 border-orange-400"
          >
            Open
          </Badge>
        );
      case "resolved":
        return (
          <Badge variant="outline" className="text-green-400 border-green-400">
            Resolved
          </Badge>
        );
      case "closed":
        return (
          <Badge variant="outline" className="text-gray-400 border-gray-400">
            Closed
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto">
        <Card className="gaming-glow">
          <CardHeader>
            <CardTitle className="font-gaming text-2xl text-center">
              Admin Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...loginForm}>
              <form
                onSubmit={loginForm.handleSubmit(onLogin)}
                className="space-y-4"
              >
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="admin"
                          className="neon-border"
                          data-testid="input-admin-username"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="••••••••"
                          className="neon-border"
                          data-testid="input-admin-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full gaming-glow"
                  disabled={loginMutation.isPending}
                  data-testid="button-admin-login"
                >
                  {loginMutation.isPending ? (
                    "Logging in..."
                  ) : (
                    <>
                      <LogIn className="mr-2 h-4 w-4" />
                      Login
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Dashboard Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="font-gaming text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage tournaments, registrations, and support tickets
          </p>
        </div>
        <Button
          onClick={onLogout}
          variant="destructive"
          disabled={logoutMutation.isPending}
          data-testid="button-admin-logout"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="gaming-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">
                  Pending Registrations
                </p>
                <p
                  className="text-2xl font-bold text-orange-400"
                  data-testid="stat-pending-registrations"
                >
                  {stats?.pendingRegistrations || 0}
                </p>
              </div>
              <Clock className="h-8 w-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>
        <Card className="gaming-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Teams</p>
                <p
                  className="text-2xl font-bold text-primary"
                  data-testid="stat-active-teams"
                >
                  {stats?.activeTeams || 0}
                </p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card className="gaming-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Support Tickets</p>
                <p
                  className="text-2xl font-bold text-secondary"
                  data-testid="stat-support-tickets"
                >
                  {stats?.supportTickets || 0}
                </p>
              </div>
              <Headset className="h-8 w-8 text-secondary" />
            </div>
          </CardContent>
        </Card>
        <Card className="gaming-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">
                  Live Tournaments
                </p>
                <p
                  className="text-2xl font-bold text-accent"
                  data-testid="stat-tournaments"
                >
                  {stats?.tournaments || 0}
                </p>
              </div>
              <Trophy className="h-8 w-8 text-accent" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Admin Tabs */}
      <Card className="gaming-glow">
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
              <TabsTrigger
                value="registrations"
                data-testid="tab-registrations"
              >
                <UserCheck className="mr-2 h-4 w-4" />
                Registrations
              </TabsTrigger>
              <TabsTrigger value="teams" data-testid="tab-teams">
                <Users className="mr-2 h-4 w-4" />
                Teams
              </TabsTrigger>
              <TabsTrigger value="support" data-testid="tab-support">
                <Headset className="mr-2 h-4 w-4" />
                Support
              </TabsTrigger>
              <TabsTrigger value="tournaments" data-testid="tab-tournaments">
                <Trophy className="mr-2 h-4 w-4" />
                Tournaments
              </TabsTrigger>
              <TabsTrigger value="rules" data-testid="tab-rules">
                <Gavel className="mr-2 h-4 w-4" />
                Rules
              </TabsTrigger>
              <TabsTrigger value="timeslots" data-testid="tab-timeslots">
                <Calendar className="mr-2 h-4 w-4" />
                Time Slots
              </TabsTrigger>
            </TabsList>

            {/* Registration Management Tab */}
            <TabsContent value="registrations" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Pending Registrations</h3>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => {
                      pendingTeams?.forEach((team: any) => {
                        updateTeamStatusMutation.mutate({
                          id: team.id,
                          status: "approved",
                        });
                      });
                    }}
                    className="bg-secondary text-secondary-foreground"
                    data-testid="button-approve-all"
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Approve All
                  </Button>
                  <Button
                    onClick={() => {
                      pendingTeams?.forEach((team: any) => {
                        updateTeamStatusMutation.mutate({
                          id: team.id,
                          status: "rejected",
                        });
                      });
                    }}
                    variant="destructive"
                    data-testid="button-reject-all"
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    Reject All
                  </Button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Team Name</TableHead>
                      <TableHead>Game</TableHead>
                      <TableHead>Leader</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingTeams && pendingTeams.length > 0 ? (
                      pendingTeams.map((team: any) => (
                        <TableRow key={team.id}>
                          <TableCell
                            className="font-medium"
                            data-testid={`team-name-${team.id}`}
                          >
                            {team.name}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                team.game === "freefire"
                                  ? "text-orange-400 border-orange-400"
                                  : "text-green-400 border-green-400"
                              }
                            >
                              {team.game === "freefire" ? "Free Fire" : "BGMI"}
                            </Badge>
                          </TableCell>
                          <TableCell data-testid={`team-leader-${team.id}`}>
                            {team.leaderName}
                          </TableCell>
                          <TableCell
                            className="text-sm text-muted-foreground"
                            data-testid={`team-email-${team.id}`}
                          >
                            {team.email}
                          </TableCell>
                          <TableCell data-testid={`team-size-${team.id}`}>
                            {team.size}
                          </TableCell>
                          <TableCell
                            className="text-sm text-muted-foreground"
                            data-testid={`team-date-${team.id}`}
                          >
                            {new Date(team.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                onClick={() =>
                                  updateTeamStatusMutation.mutate({
                                    id: team.id,
                                    status: "approved",
                                  })
                                }
                                size="sm"
                                className="bg-secondary/20 text-secondary hover:bg-secondary/30"
                                data-testid={`button-approve-${team.id}`}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                              <Button
                                onClick={() =>
                                  updateTeamStatusMutation.mutate({
                                    id: team.id,
                                    status: "rejected",
                                  })
                                }
                                size="sm"
                                variant="destructive"
                                data-testid={`button-reject-${team.id}`}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    onClick={() => setSelectedTeam(team)}
                                    size="sm"
                                    className="bg-primary/20 text-primary hover:bg-primary/30"
                                    data-testid={`button-view-${team.id}`}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>
                                      Team Details: {team.name}
                                    </DialogTitle>
                                  </DialogHeader>
                                  <div className="space-y-4">
                                    <div>
                                      <label className="text-sm font-medium">
                                        Team Members:
                                      </label>
                                      <div className="mt-2 space-y-2">
                                        {team.members?.map(
                                          (member: any, index: number) => (
                                            <div
                                              key={index}
                                              className="bg-muted/20 p-2 rounded"
                                            >
                                              <p className="font-medium">
                                                {member.name}
                                              </p>
                                              <p className="text-sm text-muted-foreground">
                                                Game ID: {member.gameId}
                                              </p>
                                            </div>
                                          ),
                                        )}
                                      </div>
                                    </div>
                                    <div>
                                      <label className="text-sm font-medium">
                                        Contact Info:
                                      </label>
                                      <p className="text-sm">
                                        Email: {team.email}
                                      </p>
                                      <p className="text-sm">
                                        Phone: {team.phone}
                                      </p>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell
                          colSpan={7}
                          className="text-center text-muted-foreground"
                        >
                          No pending registrations
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Teams Management Tab */}
            <TabsContent value="teams" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Team Management</h3>
                <div className="flex space-x-2">
                  <Input
                    placeholder="Search teams..."
                    className="w-48 neon-border"
                    data-testid="input-search-teams"
                  />
                  <Select>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="All Games" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Games</SelectItem>
                      <SelectItem value="freefire">Free Fire</SelectItem>
                      <SelectItem value="bgmi">BGMI</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                {teams && teams.length > 0 ? (
                  teams.map((team: any) => (
                    <div
                      key={team.id}
                      className="bg-input/50 rounded-lg p-4 flex items-center justify-between"
                    >
                      <div>
                        <h4
                          className="font-medium"
                          data-testid={`active-team-name-${team.id}`}
                        >
                          {team.name}
                        </h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>
                            {team.game === "freefire" ? "Free Fire" : "BGMI"}
                          </span>
                          <span>{team.leaderName}</span>
                          <span>{team.size} members</span>
                          {getStatusBadge(team.status)}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              onClick={() => setSelectedTeam(team)}
                              size="sm"
                              className="bg-primary/20 text-primary hover:bg-primary/30"
                              data-testid={`button-edit-team-${team.id}`}
                            >
                              <Edit className="mr-1 h-4 w-4" />
                              Edit
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>
                                Team Details: {team.name}
                              </DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium">
                                  Status:
                                </label>
                                <Select
                                  defaultValue={team.status}
                                  onValueChange={(value) =>
                                    updateTeamStatusMutation.mutate({
                                      id: team.id,
                                      status: value,
                                    })
                                  }
                                >
                                  <SelectTrigger className="mt-1">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">
                                      Pending
                                    </SelectItem>
                                    <SelectItem value="approved">
                                      Approved
                                    </SelectItem>
                                    <SelectItem value="rejected">
                                      Rejected
                                    </SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-sm font-medium">
                                  Team Members:
                                </label>
                                <div className="mt-2 space-y-2">
                                  {team.members?.map(
                                    (member: any, index: number) => (
                                      <div
                                        key={index}
                                        className="bg-muted/20 p-2 rounded"
                                      >
                                        <p className="font-medium">
                                          {member.name}
                                        </p>
                                        <p className="text-sm text-muted-foreground">
                                          Game ID: {member.gameId}
                                        </p>
                                      </div>
                                    ),
                                  )}
                                </div>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button
                          onClick={() => {
                            if (
                              confirm(
                                "Are you sure you want to delete this team?",
                              )
                            ) {
                              deleteTeamMutation.mutate(team.id);
                            }
                          }}
                          size="sm"
                          variant="destructive"
                          data-testid={`button-delete-team-${team.id}`}
                        >
                          <Trash2 className="mr-1 h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No teams found
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Support Tickets Tab */}
            <TabsContent value="support" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Support Tickets</h3>
                <Select>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="All Tickets" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Tickets</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                {supportTickets && supportTickets.length > 0 ? (
                  supportTickets.map((ticket: any) => (
                    <div key={ticket.id} className="bg-input/50 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4
                            className="font-medium"
                            data-testid={`ticket-subject-${ticket.id}`}
                          >
                            {ticket.subject}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            <span data-testid={`ticket-name-${ticket.id}`}>
                              {ticket.name}
                            </span>{" "}
                            •
                            <span data-testid={`ticket-email-${ticket.id}`}>
                              {" "}
                              {ticket.email}
                            </span>{" "}
                            •
                            <span data-testid={`ticket-date-${ticket.id}`}>
                              {" "}
                              {new Date(ticket.createdAt).toLocaleDateString()}
                            </span>
                          </p>
                        </div>
                        {getStatusBadge(ticket.status)}
                      </div>
                      <p
                        className="text-muted-foreground text-sm mb-3"
                        data-testid={`ticket-description-${ticket.id}`}
                      >
                        {ticket.description}
                      </p>
                      {ticket.adminReply && (
                        <div className="bg-primary/10 p-3 rounded mb-3">
                          <p className="text-sm font-medium text-primary">
                            Admin Reply:
                          </p>
                          <p className="text-sm">{ticket.adminReply}</p>
                        </div>
                      )}
                      <div className="flex space-x-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              onClick={() => setSelectedTicket(ticket)}
                              size="sm"
                              className="bg-primary/20 text-primary hover:bg-primary/30"
                              data-testid={`button-reply-ticket-${ticket.id}`}
                            >
                              <Reply className="mr-1 h-4 w-4" />
                              Reply
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Reply to Support Ticket</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium">
                                  Subject:
                                </label>
                                <p className="text-sm">{ticket.subject}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">
                                  Description:
                                </label>
                                <p className="text-sm">{ticket.description}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">
                                  Admin Reply:
                                </label>
                                <Textarea
                                  value={replyText}
                                  onChange={(e) => setReplyText(e.target.value)}
                                  placeholder="Enter your reply..."
                                  rows={4}
                                  className="neon-border"
                                />
                              </div>
                              <div className="flex space-x-2">
                                <Button
                                  onClick={() => {
                                    updateTicketMutation.mutate({
                                      id: ticket.id,
                                      status: "resolved",
                                      adminReply: replyText,
                                    });
                                  }}
                                  className="bg-secondary text-secondary-foreground"
                                >
                                  Send & Resolve
                                </Button>
                                <Button
                                  onClick={() => {
                                    updateTicketMutation.mutate({
                                      id: ticket.id,
                                      status: "open",
                                      adminReply: replyText,
                                    });
                                  }}
                                  variant="outline"
                                >
                                  Send Reply
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <Button
                          onClick={() =>
                            updateTicketMutation.mutate({
                              id: ticket.id,
                              status: "resolved",
                            })
                          }
                          size="sm"
                          className="bg-secondary/20 text-secondary hover:bg-secondary/30"
                          data-testid={`button-resolve-ticket-${ticket.id}`}
                        >
                          <CheckCircle className="mr-1 h-4 w-4" />
                          Resolve
                        </Button>
                        <Button
                          onClick={() =>
                            updateTicketMutation.mutate({
                              id: ticket.id,
                              status: "closed",
                            })
                          }
                          size="sm"
                          variant="destructive"
                          data-testid={`button-close-ticket-${ticket.id}`}
                        >
                          <XCircle className="mr-1 h-4 w-4" />
                          Close
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No support tickets found
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Tournament Management Tab */}
            <TabsContent value="tournaments" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Tournament Management</h3>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      className="bg-primary text-primary-foreground"
                      data-testid="button-create-tournament"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Create Tournament
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create New Tournament</DialogTitle>
                    </DialogHeader>
                    <Form {...tournamentForm}>
                      <form
                        onSubmit={tournamentForm.handleSubmit((data) =>
                          createTournamentMutation.mutate(data),
                        )}
                        className="space-y-4"
                      >
                        <FormField
                          control={tournamentForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Tournament Name</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Enter tournament name"
                                  className="neon-border"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={tournamentForm.control}
                          name="game"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Game</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="neon-border">
                                    <SelectValue placeholder="Select game" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="freefire">
                                    Free Fire
                                  </SelectItem>
                                  <SelectItem value="bgmi">BGMI</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={tournamentForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Tournament description"
                                  className="neon-border"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={tournamentForm.control}
                          name="maxTeams"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Max Teams</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  placeholder="64"
                                  className="neon-border"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={createTournamentMutation.isPending}
                        >
                          {createTournamentMutation.isPending
                            ? "Creating..."
                            : "Create Tournament"}
                        </Button>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="space-y-4">
                {tournaments && tournaments.length > 0 ? (
                  tournaments.map((tournament: any) => (
                    <div
                      key={tournament.id}
                      className="bg-input/50 rounded-lg p-4"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h4
                            className="font-medium text-lg"
                            data-testid={`tournament-admin-name-${tournament.id}`}
                          >
                            {tournament.name}
                          </h4>
                          <p
                            className="text-muted-foreground text-sm mb-2"
                            data-testid={`tournament-admin-description-${tournament.id}`}
                          >
                            {tournament.description ||
                              `${tournament.game} tournament`}
                          </p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span
                              className="text-primary"
                              data-testid={`tournament-admin-teams-${tournament.id}`}
                            >
                              {tournament.registeredTeams || 0}/
                              {tournament.maxTeams || 64} Teams
                            </span>
                            {tournament.startDate && (
                              <span
                                className="text-accent"
                                data-testid={`tournament-admin-date-${tournament.id}`}
                              >
                                {new Date(
                                  tournament.startDate,
                                ).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col space-y-2">
                          {getStatusBadge(tournament.status || "draft")}
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              className="bg-primary/20 text-primary hover:bg-primary/30"
                              data-testid={`button-edit-tournament-${tournament.id}`}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              onClick={() => {
                                if (
                                  confirm(
                                    "Are you sure you want to delete this tournament?",
                                  )
                                ) {
                                  deleteTournamentMutation.mutate(
                                    tournament.id,
                                  );
                                }
                              }}
                              size="sm"
                              variant="destructive"
                              data-testid={`button-delete-tournament-${tournament.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No tournaments found
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Tournament Rules Editor Tab */}
            <TabsContent value="rules" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">
                  Tournament Rules Editor
                </h3>
                <Button
                  onClick={rulesForm.handleSubmit((data) =>
                    updateRulesMutation.mutate(data),
                  )}
                  className="bg-secondary text-secondary-foreground"
                  disabled={updateRulesMutation.isPending}
                  data-testid="button-save-rules"
                >
                  <Save className="mr-2 h-4 w-4" />
                  {updateRulesMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>

              <Form {...rulesForm}>
                <form className="space-y-6">
                  <FormField
                    control={rulesForm.control}
                    name="general"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>General Rules</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={8}
                            placeholder="Enter general tournament rules..."
                            className="neon-border"
                            data-testid="textarea-general-rules"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={rulesForm.control}
                    name="devices"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Device Requirements</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={6}
                            placeholder="Enter device requirements..."
                            className="neon-border"
                            data-testid="textarea-device-requirements"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={rulesForm.control}
                    name="fairPlay"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fair Play Policy</FormLabel>
                        <FormControl>
                          <Textarea
                            rows={5}
                            placeholder="Enter fair play policies..."
                            className="neon-border"
                            data-testid="textarea-fair-play"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </TabsContent>

            {/* Time Slots Tab */}
            <TabsContent value="timeslots" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">Tournament Time Slots</h3>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      className="bg-primary text-primary-foreground"
                      data-testid="button-add-timeslot"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Time Slot
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Time Slot</DialogTitle>
                    </DialogHeader>
                    <Form {...timeSlotForm}>
                      <form
                        onSubmit={timeSlotForm.handleSubmit((data) =>
                          createTimeSlotMutation.mutate(data),
                        )}
                        className="space-y-4"
                      >
                        <FormField
                          control={timeSlotForm.control}
                          name="tournamentId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Tournament (Optional)</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="neon-border">
                                    <SelectValue placeholder="Select tournament" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {tournaments?.map((tournament: any) => (
                                    <SelectItem
                                      key={tournament.id}
                                      value={tournament.id}
                                    >
                                      {tournament.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={timeSlotForm.control}
                          name="date"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date</FormLabel>
                              <FormControl>
                                <Input
                                  type="date"
                                  className="neon-border"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={timeSlotForm.control}
                            name="startTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Start Time</FormLabel>
                                <FormControl>
                                  <Input
                                    type="time"
                                    className="neon-border"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={timeSlotForm.control}
                            name="endTime"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>End Time</FormLabel>
                                <FormControl>
                                  <Input
                                    type="time"
                                    className="neon-border"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={timeSlotForm.control}
                          name="maxTeams"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Max Teams</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  placeholder="8"
                                  className="neon-border"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={createTimeSlotMutation.isPending}
                        >
                          {createTimeSlotMutation.isPending
                            ? "Creating..."
                            : "Create Time Slot"}
                        </Button>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Available Slots</h4>
                  <div className="space-y-2">
                    {timeSlots
                      ?.filter(
                        (slot: any) =>
                          !slot.assignedTeams ||
                          slot.assignedTeams.length === 0,
                      )
                      .map((slot: any) => (
                        <div
                          key={slot.id}
                          className="bg-secondary/10 border border-secondary/30 rounded-lg p-3 flex items-center justify-between"
                        >
                          <div>
                            <div
                              className="font-medium"
                              data-testid={`slot-time-${slot.id}`}
                            >
                              {slot.startTime} - {slot.endTime}
                            </div>
                            <div
                              className="text-sm text-muted-foreground"
                              data-testid={`slot-date-${slot.id}`}
                            >
                              {new Date(slot.date).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span
                              className="text-xs text-secondary"
                              data-testid={`slot-capacity-${slot.id}`}
                            >
                              0/{slot.maxTeams} teams
                            </span>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-primary hover:text-primary/80"
                                  data-testid={`button-assign-${slot.id}`}
                                  onClick={() => {
                                    setSelectedSlot(slot);
                                    setSelectedTeamsForSlot(
                                      slot.assignedTeams || [],
                                    );
                                  }}
                                >
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-md">
                                <DialogHeader>
                                  <DialogTitle>
                                    Assign Teams to Time Slot
                                  </DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <p className="text-sm text-muted-foreground">
                                      Time: {slot.startTime} - {slot.endTime}
                                    </p>
                                    <p className="text-sm text-muted-foreground">
                                      Date:{" "}
                                      {new Date(slot.date).toLocaleDateString()}
                                    </p>
                                    <p className="text-sm text-muted-foreground">
                                      Max Teams: {slot.maxTeams}
                                    </p>
                                  </div>
                                  <div className="space-y-2">
                                    <h4 className="font-medium">
                                      Select Teams:
                                    </h4>
                                    <div className="max-h-48 overflow-y-auto space-y-2">
                                      {approvedTeams?.map((team: any) => (
                                        <div
                                          key={team.id}
                                          className="flex items-center space-x-2"
                                        >
                                          <input
                                            type="checkbox"
                                            id={team.id}
                                            checked={selectedTeamsForSlot.includes(
                                              team.id,
                                            )}
                                            onChange={(e) => {
                                              if (e.target.checked) {
                                                setSelectedTeamsForSlot(
                                                  (prev) => [...prev, team.id],
                                                );
                                              } else {
                                                setSelectedTeamsForSlot(
                                                  (prev) =>
                                                    prev.filter(
                                                      (id) => id !== team.id,
                                                    ),
                                                );
                                              }
                                            }}
                                            disabled={
                                              selectedTeamsForSlot.length >=
                                                slot.maxTeams &&
                                              !selectedTeamsForSlot.includes(
                                                team.id,
                                              )
                                            }
                                            data-testid={`checkbox-team-${team.id}`}
                                          />
                                          <label
                                            htmlFor={team.id}
                                            className="text-sm"
                                          >
                                            {team.name} (
                                            {team.game.toUpperCase()})
                                          </label>
                                        </div>
                                      )) || (
                                        <div className="text-center text-muted-foreground py-4">
                                          No approved teams available
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex justify-between">
                                    <Button
                                      variant="outline"
                                      onClick={() => {
                                        setSelectedSlot(null);
                                        setSelectedTeamsForSlot([]);
                                      }}
                                    >
                                      Cancel
                                    </Button>
                                    <Button
                                      onClick={() => {
                                        assignTeamsToSlotMutation.mutate({
                                          slotId: slot.id,
                                          teamIds: selectedTeamsForSlot,
                                        });
                                      }}
                                      disabled={
                                        assignTeamsToSlotMutation.isPending
                                      }
                                      data-testid={`button-confirm-assign-${slot.id}`}
                                    >
                                      {assignTeamsToSlotMutation.isPending
                                        ? "Assigning..."
                                        : "Assign Teams"}
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button
                              onClick={() => {
                                if (
                                  confirm(
                                    "Are you sure you want to delete this time slot?",
                                  )
                                ) {
                                  deleteTimeSlotMutation.mutate(slot.id);
                                }
                              }}
                              size="sm"
                              variant="ghost"
                              className="text-destructive hover:text-destructive/80"
                              data-testid={`button-delete-slot-${slot.id}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )) || (
                      <div className="text-center text-muted-foreground py-4">
                        No available slots
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Assigned Slots</h4>
                  <div className="space-y-2">
                    {timeSlots
                      ?.filter(
                        (slot: any) =>
                          slot.assignedTeams && slot.assignedTeams.length > 0,
                      )
                      .map((slot: any) => (
                        <div
                          key={slot.id}
                          className="bg-primary/10 border border-primary/30 rounded-lg p-3"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div
                              className="font-medium"
                              data-testid={`assigned-slot-time-${slot.id}`}
                            >
                              {slot.startTime} - {slot.endTime}
                            </div>
                            <span
                              className="text-xs text-primary"
                              data-testid={`assigned-slot-capacity-${slot.id}`}
                            >
                              {slot.assignedTeams?.length || 0}/{slot.maxTeams}{" "}
                              teams
                            </span>
                          </div>
                          <div
                            className="text-sm text-muted-foreground"
                            data-testid={`assigned-slot-date-${slot.id}`}
                          >
                            {new Date(slot.date).toLocaleDateString()}
                          </div>
                          <div className="mt-2 text-xs">
                            <span className="text-muted-foreground">
                              Teams:
                            </span>
                            <div className="mt-1 space-y-1">
                              {slot.assignedTeams?.map((teamId: string) => {
                                const team = teams?.find(
                                  (t: any) => t.id === teamId,
                                );
                                return team ? (
                                  <div
                                    key={teamId}
                                    className="flex items-center justify-between text-xs bg-background/50 rounded px-2 py-1"
                                  >
                                    <span>{team.name}</span>
                                    <span className="text-muted-foreground">
                                      ({team.game.toUpperCase()})
                                    </span>
                                  </div>
                                ) : null;
                              }) || (
                                <div className="text-muted-foreground">
                                  No teams assigned
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )) || (
                      <div className="text-center text-muted-foreground py-4">
                        No assigned slots
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
