import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Eye, Lock, UserCheck } from "lucide-react";
import { Link } from "wouter";

export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="font-gaming text-3xl font-bold mb-4">Privacy Policy</h1>
        <p className="text-muted-foreground">How we collect, use, and protect your information</p>
      </div>

      <Card className="gaming-glow">
        <CardContent className="p-6 md:p-8">
          <p className="text-muted-foreground mb-6">Last updated: December 2024</p>
          
          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary flex items-center">
                <Eye className="mr-3" />
                Information We Collect
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Team and player registration information
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Contact details (email, phone number)
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Game IDs and usernames
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Tournament participation data
                  </li>
                  <li className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    Support ticket communications
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4 text-secondary flex items-center">
                <UserCheck className="mr-3" />
                How We Use Your Information
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start">
                    <span className="text-secondary mr-2">•</span>
                    Tournament registration and management
                  </li>
                  <li className="flex items-start">
                    <span className="text-secondary mr-2">•</span>
                    Communication regarding matches and events
                  </li>
                  <li className="flex items-start">
                    <span className="text-secondary mr-2">•</span>
                    Technical support and assistance
                  </li>
                  <li className="flex items-start">
                    <span className="text-secondary mr-2">•</span>
                    Prize distribution and winner announcements
                  </li>
                  <li className="flex items-start">
                    <span className="text-secondary mr-2">•</span>
                    Platform improvement and analytics
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4 text-accent flex items-center">
                <Lock className="mr-3" />
                Data Security
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <p className="text-muted-foreground">
                  We implement appropriate security measures to protect your personal information against 
                  unauthorized access, alteration, disclosure, or destruction. All data is stored securely 
                  and access is limited to authorized personnel only. We use industry-standard encryption 
                  and security protocols to safeguard your information.
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4 text-orange-400 flex items-center">
                <Shield className="mr-3" />
                Your Rights
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    Access your personal data
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    Request data correction or deletion
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    Withdraw consent for data processing
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    Data portability rights
                  </li>
                  <li className="flex items-start">
                    <span className="text-orange-400 mr-2">•</span>
                    Object to processing for direct marketing
                  </li>
                </ul>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary flex items-center">
                <Shield className="mr-3" />
                Data Retention
              </h3>
              <div className="bg-muted/20 rounded-lg p-4">
                <p className="text-muted-foreground">
                  We retain your personal information only for as long as necessary to provide our services 
                  and fulfill the purposes outlined in this privacy policy. Tournament data may be retained 
                  for statistical and historical purposes. You can request deletion of your data at any time 
                  by contacting our support team.
                </p>
              </div>
            </div>
            
            <div className="bg-primary/10 rounded-lg p-4">
              <h4 className="font-semibold mb-2 text-primary flex items-center">
                <Shield className="mr-2 h-5 w-5" />
                Contact Us
              </h4>
              <p className="text-sm text-muted-foreground">
                For any privacy-related questions or concerns, please contact our support team 
                through the{" "}
                <Link href="/support" className="text-primary hover:underline" data-testid="link-support">
                  support section
                </Link>
                . We are committed to addressing your privacy concerns promptly and transparently.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
