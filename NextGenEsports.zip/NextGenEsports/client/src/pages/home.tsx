import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Users, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-card via-card/50 to-background rounded-2xl p-8 md:p-12 gaming-glow overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-secondary/10"></div>
        <div className="relative z-10">
          <div className="text-center mb-12">
            <h1 className="font-gaming text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              NEXTGEN ARENA
            </h1>
            <p className="text-xl text-muted-foreground mb-8">Elite Esports Tournament Registration</p>
            
            {/* Game Logos */}
            <div className="flex justify-center items-center space-x-8 mb-8">
              {/* Free Fire Logo */}
              <img 
                src="/attached_assets/image_1756341582655.png" 
                alt="Free Fire" 
                className="w-20 h-20 rounded-xl gaming-glow object-cover"
              />
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
              </div>
              {/* BGMI Logo */}
              <img 
                src="/attached_assets/image_1756341617664.png" 
                alt="BGMI" 
                className="w-20 h-20 rounded-xl gaming-glow object-cover"
              />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="text-center" data-testid="stat-active-teams">
              <div className="text-2xl font-bold text-primary">{stats?.activeTeams || 0}</div>
              <div className="text-sm text-muted-foreground">Active Teams</div>
            </div>
            <div className="text-center" data-testid="stat-tournaments">
              <div className="text-2xl font-bold text-secondary">{stats?.tournaments || 0}</div>
              <div className="text-sm text-muted-foreground">Live Tournaments</div>
            </div>
            <div className="text-center" data-testid="stat-players">
              <div className="text-2xl font-bold text-orange-400">{stats?.totalPlayers || 0}</div>
              <div className="text-sm text-muted-foreground">Registered Players</div>
            </div>
          </div>

          {/* CTA Button */}
          <div className="text-center">
            <Button asChild className="bg-primary text-primary-foreground px-8 py-4 text-lg gaming-glow hover:bg-primary/90">
              <Link href="/tournaments" data-testid="button-register-team">
                <Trophy className="mr-2 h-5 w-5" />
                Register Your Team
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-card rounded-xl p-6 gaming-glow text-center">
          <Users className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Team Registration</h3>
          <p className="text-muted-foreground">Easy team registration process with instant confirmation and status tracking.</p>
        </div>
        
        <div className="bg-card rounded-xl p-6 gaming-glow text-center">
          <Calendar className="h-12 w-12 text-secondary mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Scheduled Matches</h3>
          <p className="text-muted-foreground">Organized time slots and match scheduling for seamless tournament experience.</p>
        </div>
        
        <div className="bg-card rounded-xl p-6 gaming-glow text-center">
          <Trophy className="h-12 w-12 text-accent mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Tournament Rewards</h3>
          <p className="text-muted-foreground">Compete for glory and recognition in our competitive tournament environment.</p>
        </div>
      </div>
    </div>
  );
}
