import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trophy, Users, Calendar, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const registrationSchema = z.object({
  name: z.string().min(3, "Team name must be at least 3 characters"),
  game: z.enum(["freefire", "bgmi"], { required_error: "Please select a game" }),
  leaderName: z.string().min(2, "Leader name is required"),
  email: z.string().email("Valid email is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  size: z.coerce.number().min(1).max(4),
  members: z.array(z.object({
    name: z.string().min(1, "Player name is required"),
    gameId: z.string().min(1, "Game ID is required"),
  })).min(1, "At least one team member is required"),
  agreeToTerms: z.boolean().refine(val => val === true, "You must agree to the terms and conditions"),
});

type RegistrationFormData = z.infer<typeof registrationSchema>;

export default function Tournaments() {
  const [memberCount, setMemberCount] = useState(1);
  const { toast } = useToast();

  const { data: tournaments, isLoading: tournamentsLoading } = useQuery({
    queryKey: ["/api/tournaments"],
  });

  const form = useForm<RegistrationFormData>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      name: "",
      game: undefined,
      leaderName: "",
      email: "",
      phone: "",
      size: 4,
      members: [{ name: "", gameId: "" }],
      agreeToTerms: false,
    },
  });

  const teamSize = form.watch("size");

  const registrationMutation = useMutation({
    mutationFn: async (data: RegistrationFormData) => {
      const { agreeToTerms, ...teamData } = data;
      return await apiRequest("POST", "/api/teams", teamData);
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful!",
        description: "Your team has been registered. You will receive a confirmation email shortly.",
      });
      form.reset();
      setMemberCount(1);
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to register team. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addMember = () => {
    const currentMembers = form.getValues("members");
    if (currentMembers.length < teamSize) {
      form.setValue("members", [...currentMembers, { name: "", gameId: "" }]);
      setMemberCount(prev => prev + 1);
    }
  };

  const removeMember = (index: number) => {
    const currentMembers = form.getValues("members");
    if (currentMembers.length > 1) {
      const newMembers = currentMembers.filter((_, i) => i !== index);
      form.setValue("members", newMembers);
      setMemberCount(prev => prev - 1);
    }
  };

  const onSubmit = (data: RegistrationFormData) => {
    registrationMutation.mutate(data);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="font-gaming text-3xl font-bold mb-4">Tournament Registration</h1>
        <p className="text-muted-foreground">Join the competition and compete for amazing prizes!</p>
      </div>

      {/* Registration Form */}
      <Card className="gaming-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="mr-3 text-primary" />
            Team Registration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter team name" 
                          className="neon-border"
                          data-testid="input-team-name"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="game"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Game Selection *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="neon-border" data-testid="select-game">
                            <SelectValue placeholder="Select Game" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="freefire">Free Fire</SelectItem>
                          <SelectItem value="bgmi">BGMI</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="leaderName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Leader Name *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Captain's name" 
                          className="neon-border"
                          data-testid="input-leader-name"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address *</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="team@example.com" 
                          className="neon-border"
                          data-testid="input-email"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number *</FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          placeholder="+91 XXXXX XXXXX" 
                          className="neon-border"
                          data-testid="input-phone"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="size"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Size *</FormLabel>
                      <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger className="neon-border" data-testid="select-team-size">
                            <SelectValue placeholder="Select team size" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="4">4 Players (Squad)</SelectItem>
                          <SelectItem value="2">2 Players (Duo)</SelectItem>
                          <SelectItem value="1">1 Player (Solo)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Team Members Section */}
              <div>
                <h4 className="text-lg font-medium mb-4">Team Members</h4>
                <div className="space-y-4">
                  {form.watch("members").map((_, index) => (
                    <div key={index} className="grid md:grid-cols-3 gap-4 p-4 bg-input/50 rounded-lg">
                      <FormField
                        control={form.control}
                        name={`members.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input 
                                placeholder="Player name" 
                                className="neon-border"
                                data-testid={`input-member-name-${index}`}
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`members.${index}.gameId`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input 
                                placeholder="Game ID" 
                                className="neon-border"
                                data-testid={`input-member-game-id-${index}`}
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      {index > 0 && (
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => removeMember(index)}
                          data-testid={`button-remove-member-${index}`}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  ))}
                  
                  {form.watch("members").length < teamSize && (
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={addMember}
                      className="text-primary hover:text-primary/80"
                      data-testid="button-add-member"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add Team Member
                    </Button>
                  )}
                </div>
              </div>

              {/* Terms and Conditions */}
              <FormField
                control={form.control}
                name="agreeToTerms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="checkbox-agree-terms"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-sm">
                        I agree to the tournament rules and privacy policy. I confirm that all team members have their own phones and internet connection.
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full gaming-glow" 
                disabled={registrationMutation.isPending}
                data-testid="button-submit-registration"
              >
                {registrationMutation.isPending ? (
                  "Submitting..."
                ) : (
                  <>
                    <Trophy className="mr-2 h-4 w-4" />
                    Submit Registration
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Active Tournaments */}
      <Card className="gaming-glow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Trophy className="mr-3 text-secondary" />
            Active Tournaments
          </CardTitle>
        </CardHeader>
        <CardContent>
          {tournamentsLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading tournaments...</p>
            </div>
          ) : tournaments && tournaments.length > 0 ? (
            <div className="space-y-4">
              {tournaments.map((tournament: any) => (
                <div key={tournament.id} className="border border-border rounded-lg p-4 hover:border-primary/50 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-center justify-between">
                    <div className="mb-4 md:mb-0">
                      <h4 className="font-semibold text-lg" data-testid={`tournament-name-${tournament.id}`}>
                        {tournament.name}
                      </h4>
                      <p className="text-muted-foreground text-sm" data-testid={`tournament-description-${tournament.id}`}>
                        {tournament.description || `${tournament.game} tournament`}
                      </p>
                      <div className="flex items-center space-x-4 mt-2 text-xs">
                        <span className="text-primary" data-testid={`tournament-teams-${tournament.id}`}>
                          {tournament.registeredTeams || 0}/{tournament.maxTeams || 64} Teams
                        </span>
                        {tournament.startDate && (
                          <span className="text-accent" data-testid={`tournament-date-${tournament.id}`}>
                            {new Date(tournament.startDate).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <span className="px-3 py-1 bg-secondary/20 text-secondary text-xs rounded-full text-center">
                        {tournament.status || "Registration Open"}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No active tournaments at the moment.</p>
              <p className="text-sm">Check back soon for new competitions!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
