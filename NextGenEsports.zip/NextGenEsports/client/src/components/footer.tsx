import { Link } from "wouter";
import { FaDiscord, FaYoutube, FaInstagram, FaTelegram } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="/attached_assets/generated_images/NextGen_Arena_esports_logo_0b0b51f9.png" 
                alt="NextGen Arena" 
                className="w-8 h-8 rounded-lg"
              />
              <span className="font-gaming text-lg font-bold text-primary">NextGen Arena</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Premier esports tournament platform for Free Fire and BGMI competitions.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-muted-foreground text-sm">
              <li>
                <Link href="/tournaments" className="hover:text-primary transition-colors" data-testid="link-footer-tournaments">
                  Tournaments
                </Link>
              </li>
              <li>
                <Link href="/rules" className="hover:text-primary transition-colors" data-testid="link-footer-rules">
                  Rules
                </Link>
              </li>
              <li>
                <Link href="/support" className="hover:text-primary transition-colors" data-testid="link-footer-support">
                  Support
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-primary transition-colors" data-testid="link-footer-privacy">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Connect With Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-discord">
                <FaDiscord className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-youtube">
                <FaYoutube className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-instagram">
                <FaInstagram className="text-xl" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors" data-testid="link-telegram">
                <FaTelegram className="text-xl" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2024 NextGen Arena. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
