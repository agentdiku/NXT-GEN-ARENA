# NextGen Arena - Esports Tournament Platform

## Overview

NextGen Arena is an esports tournament registration platform that supports Free Fire and BGMI competitions. The application provides a complete tournament management system with team registration, admin controls, support ticketing, and rule management. It's built as a full-stack web application with a modern React frontend and Express backend, designed to handle tournament workflows from registration to completion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built with React 18 using Vite as the build tool and bundler. The application uses a component-based architecture with:
- **Routing**: Wouter for client-side routing with pages for home, tournaments, rules, support, privacy, and admin
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Form Handling**: React Hook Form with Zod validation schemas
- **Component Structure**: Modular components with shared UI components in `/components/ui/` and page-specific components

### Backend Architecture
The server is built with Express.js following a RESTful API design:
- **Server Framework**: Express.js with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL database (Neon serverless)
- **Authentication**: Session-based authentication using express-session with PostgreSQL session store
- **Password Security**: Bcrypt for password hashing and verification
- **API Structure**: Centralized routes in `routes.ts` with separated concerns for authentication, storage, and business logic

### Database Design
PostgreSQL database with Drizzle ORM managing:
- **Admin Management**: Admin users with session-based authentication
- **Tournament System**: Tournament creation, management, and status tracking
- **Team Registration**: Team data, member information, and approval workflows
- **Support System**: Ticket creation and resolution tracking
- **Time Slot Management**: Tournament scheduling functionality
- **Rule Management**: Dynamic tournament rules and guidelines

### Authentication & Authorization
- **Admin Authentication**: Session-based auth with secure password hashing
- **Session Storage**: PostgreSQL-backed session store with configurable TTL
- **Route Protection**: Middleware-based authentication checks for admin routes
- **Security Features**: HTTP-only cookies, CSRF protection, and secure session configuration

### Development & Deployment Architecture
- **Build System**: Vite for frontend bundling with hot module replacement
- **Development Server**: Express with Vite middleware integration
- **TypeScript**: Full TypeScript support across frontend and backend
- **Environment Configuration**: Environment-based configuration for database connections and security settings

## External Dependencies

### Database & Storage
- **Neon PostgreSQL**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Database ORM and query builder
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### Frontend Libraries
- **React Ecosystem**: React 18 with Vite build tooling
- **UI Components**: Radix UI primitives with Shadcn/ui component library
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack Query for API state management
- **Form Management**: React Hook Form with Hookform resolvers
- **Validation**: Zod for schema validation
- **Routing**: Wouter for lightweight client-side routing

### Backend Dependencies
- **Express.js**: Web framework with middleware support
- **Authentication**: express-session with bcrypt password hashing
- **Development Tools**: tsx for TypeScript execution, esbuild for production builds
- **WebSocket Support**: ws library for Neon database connections

### Development Tools
- **TypeScript**: Type checking and development experience
- **ESLint/Prettier**: Code formatting and linting
- **PostCSS**: CSS processing with Tailwind CSS integration
- **Replit Integration**: Custom plugins for Replit development environment