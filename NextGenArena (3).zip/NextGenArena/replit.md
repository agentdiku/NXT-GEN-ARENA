# Tournament Registration System

## Overview

A comprehensive tournament registration and management system built for gaming competitions, specifically designed for Free Fire and PUBG Mobile tournaments. The application provides a streamlined wizard-based registration process with support for team management, participant tracking across different academic levels (1st PU and 2nd PU), and complete admin approval workflow.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development
- **UI Components**: Shadcn/ui component library built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom gaming-themed design system featuring gradient backgrounds, neon accents, and animated elements
- **Routing**: Wouter for lightweight client-side routing with public and admin routes
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Authentication**: Session-based admin authentication with password protection

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for REST API endpoints
- **Language**: TypeScript for full-stack type safety
- **Storage Layer**: Abstracted storage interface (IStorage) with in-memory implementation for development
- **API Design**: RESTful endpoints for team registration, admin management, and data retrieval
- **Admin System**: Password-protected admin routes with team approval/rejection workflow
- **Request Logging**: Custom middleware for API request/response logging
- **Admin Password**: Secured with configurable admin password (7204952616@5566)

### Data Storage Solutions
- **Database**: PostgreSQL configured with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for database migrations and schema synchronization
- **Connection**: Neon Database serverless PostgreSQL for production deployment
- **Session Storage**: Connect-pg-simple for PostgreSQL-backed session management

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL backing store
- **Security**: CORS configuration and request validation middleware
- **Data Validation**: Zod schemas for runtime type checking and input validation

### Build and Development
- **Build Tool**: Vite for fast development and optimized production builds
- **Development Server**: Vite dev server with HMR (Hot Module Replacement)
- **Production Build**: ESBuild for server bundling, Vite for client assets
- **Environment**: Separate development and production configurations

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Connection Pool**: @neondatabase/serverless for optimized database connections

### UI and Design Libraries
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for managing component variants
- **Tailwind CSS**: Utility-first CSS framework with custom gaming theme

### Development and Build Tools
- **Vite**: Build tool and development server
- **ESBuild**: Fast JavaScript bundler for production
- **TypeScript**: Static type checking across the entire application
- **Drizzle Kit**: Database schema management and migration tool

### Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### Utility Libraries
- **Date-fns**: Modern JavaScript date utility library
- **CLSX**: Utility for constructing className strings conditionally
- **Nanoid**: URL-safe unique string ID generator

### Development Environment
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **Runtime Error Overlay**: Development error handling and display
- **Cartographer**: Code mapping and navigation tools for Replit