import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Shield, Eye, Database, Mail, Users, AlertTriangle } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gaming-gradient py-6 sm:py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6 sm:space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="font-orbitron text-3xl sm:text-4xl font-bold text-gradient">
            PRIVACY POLICY & DATA PROTECTION
          </h1>
          <p className="text-slate-300 text-base sm:text-lg">
            How we collect, use, and protect your personal information
          </p>
        </div>

        {/* Information Collection */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-cyan flex items-center">
                <Database className="mr-3" size={28} />
                INFORMATION WE COLLECT
              </h2>
              <div className="space-y-4 text-slate-300">
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-cyan">
                  <h3 className="font-semibold text-white mb-2">📝 Registration Information</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Team name and member names</li>
                    <li>• Game UIDs for tournament participation</li>
                    <li>• Team captain's email address for communication</li>
                    <li>• Academic level (1st PU or 2nd PU) for category placement</li>
                  </ul>
                </div>
                
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-purple">
                  <h3 className="font-semibold text-white mb-2">🎮 Tournament Data</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Game preference (Free Fire or PUBG Mobile)</li>
                    <li>• Registration timestamps and status</li>
                    <li>• Team approval and participation records</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Usage */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-purple flex items-center">
                <Eye className="mr-3" size={28} />
                HOW WE USE YOUR INFORMATION
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Users className="mr-2" size={16} />
                      Tournament Management
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Processing team registrations</li>
                      <li>• Creating tournament brackets</li>
                      <li>• Managing match schedules</li>
                      <li>• Tracking participation statistics</li>
                    </ul>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Mail className="mr-2" size={16} />
                      Communication Purposes
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Sending registration confirmations</li>
                      <li>• Tournament updates and announcements</li>
                      <li>• Meeting schedules with organizers</li>
                      <li>• Support ticket responses</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Protection */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-green flex items-center">
                <Shield className="mr-3" size={28} />
                DATA PROTECTION & SECURITY
              </h2>
              <div className="space-y-4 text-slate-300">
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-green">
                  <h3 className="font-semibold text-white mb-2">🔒 Security Measures</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• All data is stored securely and encrypted</li>
                    <li>• Access limited to authorized tournament organizers only</li>
                    <li>• Regular security updates and monitoring</li>
                    <li>• No sharing of personal information with third parties</li>
                  </ul>
                </div>
                
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-blue-500">
                  <h3 className="font-semibold text-white mb-2">📧 Email Privacy</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Captain emails used only for tournament communication</li>
                    <li>• No promotional emails or spam</li>
                    <li>• Email addresses not shared with external parties</li>
                    <li>• You can request email removal after tournament completion</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Retention & Rights */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-yellow flex items-center">
                <AlertTriangle className="mr-3" size={28} />
                YOUR RIGHTS & DATA RETENTION
              </h2>
              <div className="space-y-4 text-slate-300">
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-yellow">
                  <h3 className="font-semibold text-white mb-2">⏰ Data Retention Policy</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Registration data kept for the duration of the tournament</li>
                    <li>• Historical records maintained for 1 year for reference</li>
                    <li>• Data can be deleted upon request after tournament completion</li>
                  </ul>
                </div>
                
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-cyan">
                  <h3 className="font-semibold text-white mb-2">🛡️ Your Rights</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Request access to your stored data</li>
                    <li>• Update or correct your information</li>
                    <li>• Request deletion of your data</li>
                    <li>• Withdraw consent for data processing</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="card-glow border-0">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h3 className="font-orbitron text-xl font-bold text-white">
                QUESTIONS ABOUT YOUR PRIVACY?
              </h3>
              <p className="text-slate-300 text-sm">
                If you have any concerns about how we handle your data, please contact us through our support system.
              </p>
              <Link href="/support">
                <Button 
                  className="px-6 py-2 btn-gaming text-white font-semibold"
                  data-testid="button-contact-support"
                >
                  CONTACT SUPPORT
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="text-center">
          <Link href="/">
            <Button 
              className="px-8 py-3 btn-gaming text-white font-bold"
              data-testid="button-back-home"
            >
              <ArrowLeft className="mr-2" size={16} />
              BACK TO REGISTRATION
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}