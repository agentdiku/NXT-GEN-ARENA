import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Smartphone, Wifi, Users, Clock, Map, Shield } from "lucide-react";

export default function TournamentRules() {
  return (
    <div className="min-h-screen bg-gaming-gradient py-6 sm:py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6 sm:space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="font-orbitron text-3xl sm:text-4xl font-bold text-gradient">
            TOURNAMENT RULES & REGULATIONS
          </h1>
          <p className="text-slate-300 text-base sm:text-lg">
            Important guidelines and requirements for Next Gen Arena tournaments
          </p>
        </div>

        {/* BYOD Policy */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-cyan flex items-center">
                <Smartphone className="mr-3" size={28} />
                BRING YOUR OWN DEVICE (BYOD) POLICY
              </h2>
              <div className="space-y-4 text-slate-300">
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-cyan">
                  <h3 className="font-semibold text-white mb-2">📱 Device Requirements</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• All participants must bring their own mobile devices</li>
                    <li>• Devices must be capable of running Free Fire or PUBG Mobile smoothly</li>
                    <li>• Ensure your device is fully charged before the tournament</li>
                    <li>• Backup power banks are recommended for longer sessions</li>
                  </ul>
                </div>
                
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-red-500">
                  <h3 className="font-semibold text-white mb-2">⚠️ Important Notice</h3>
                  <p className="text-sm">
                    Next Gen Arena will <strong className="text-red-400">NOT provide internet connectivity</strong> during the tournament. 
                    Participants are responsible for their own data plans and network connectivity.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Meeting Requirements */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-purple flex items-center">
                <Users className="mr-3" size={28} />
                REGISTRATION & MEETING REQUIREMENTS
              </h2>
              <div className="space-y-4 text-slate-300">
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-purple">
                  <h3 className="font-semibold text-white mb-2">🤝 Post-Registration Meeting</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• After completing online registration, teams must meet with the tournament organizer/head</li>
                    <li>• This meeting is mandatory for all registered teams</li>
                    <li>• Meeting details will be shared via the captain's registered email</li>
                    <li>• Bring valid college ID cards for verification</li>
                  </ul>
                </div>
                
                <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-gaming-green">
                  <h3 className="font-semibold text-white mb-2">📋 What to Expect</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Tournament schedule and match timings</li>
                    <li>• Venue details and seating arrangements</li>
                    <li>• Rules clarification and Q&A session</li>
                    <li>• Collection of participation certificates</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* General Rules */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <h2 className="font-orbitron text-2xl font-bold text-gaming-green flex items-center">
                <Shield className="mr-3" size={28} />
                GENERAL TOURNAMENT RULES
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Clock className="mr-2" size={16} />
                      Timing & Schedule
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Arrive 30 minutes before scheduled match time</li>
                      <li>• Matches start promptly as per schedule</li>
                      <li>• Late teams may be disqualified</li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Users className="mr-2" size={16} />
                      Team Requirements
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Maximum 4 players per team</li>
                      <li>• All team members must be from same PU level</li>
                      <li>• Valid college ID required for verification</li>
                    </ul>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Map className="mr-2" size={16} />
                      Gameplay Rules
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Standard game modes and maps</li>
                      <li>• No external cheats or hacks allowed</li>
                      <li>• Referee decisions are final</li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <h3 className="font-semibold text-white mb-2 flex items-center">
                      <Wifi className="mr-2" size={16} />
                      Connectivity
                    </h3>
                    <ul className="space-y-1 text-sm text-slate-300">
                      <li>• Participants responsible for own internet</li>
                      <li>• No venue Wi-Fi provided</li>
                      <li>• Network issues are player's responsibility</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="text-center">
          <Link href="/">
            <Button 
              className="px-8 py-3 btn-gaming text-white font-bold"
              data-testid="button-back-home"
            >
              <ArrowLeft className="mr-2" size={16} />
              BACK TO REGISTRATION
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}