import { useState } from "react";
import { Link } from "wouter";
import { Gamepad2, Users, Clock, Trophy, Flag, GraduationCap, User } from "lucide-react";
import TournamentWizard from "../components/tournament-wizard";

export default function Home() {
  return (
    <div className="min-h-screen bg-gaming-gradient">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gaming-cyan/10 to-gaming-purple/10"></div>
        <div className="relative container mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            {/* Gaming Controller Icon as Logo */}
            <div className="relative">
              <div className="w-16 h-16 bg-gradient-to-br from-gaming-cyan to-gaming-purple rounded-xl flex items-center justify-center animate-float">
                <Gamepad2 className="text-2xl text-white" size={32} />
              </div>
              <div className="absolute -inset-1 bg-gradient-to-r from-gaming-cyan to-gaming-purple rounded-xl blur opacity-30 animate-glow"></div>
            </div>
            <div className="text-center">
              <h1 className="font-orbitron text-2xl sm:text-4xl md:text-5xl font-black text-gradient">NEXT GEN ARENA</h1>
              <p className="text-slate-300 font-medium tracking-wider text-xs sm:text-sm">TOURNAMENT REGISTRATION SYSTEM</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 py-6 sm:py-8 max-w-6xl">
        <TournamentWizard />
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-slate-800">
        <div className="container mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <div className="text-center">
            <div className="font-orbitron text-lg font-bold text-gradient mb-2">NEXT GEN ARENA</div>
            <p className="text-slate-400 text-sm">Empowering the next generation of esports champions</p>
            <div className="mt-4 flex flex-wrap justify-center gap-4 text-sm text-slate-500">
              <Link href="/dashboard" className="hover:text-gaming-cyan transition-colors" data-testid="link-dashboard">
                Tournament Dashboard
              </Link>
              <Link href="/admin" className="hover:text-gaming-purple transition-colors" data-testid="link-admin">
                Admin Panel
              </Link>
              <Link href="/rules" className="hover:text-gaming-cyan transition-colors" data-testid="link-rules">
                Tournament Rules
              </Link>
              <Link href="/support" className="hover:text-gaming-cyan transition-colors" data-testid="link-support">
                Contact Support
              </Link>
              <Link href="/privacy" className="hover:text-gaming-cyan transition-colors" data-testid="link-privacy">
                Privacy Policy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
