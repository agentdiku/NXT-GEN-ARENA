import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Shield, Users, CheckCircle, XCircle, Clock, AlertTriangle, User, Crown, MessageCircle, Mail, Send, Reply } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdminLogin from "@/components/admin-login";
import type { TeamWithParticipants, SupportTicket } from "@shared/schema";

interface AdminStats {
  totalTeams: number;
  totalPlayers: number;
  freeFireTeams: number;
  pubgTeams: number;
  firstPUTeams: number;
  secondPUTeams: number;
  pendingTeams: number;
  rejectedTeams: number;
}

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState("pending");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ['/api/stats'],
    enabled: isAuthenticated,
  });

  const { data: pendingTeams, isLoading: pendingLoading } = useQuery<TeamWithParticipants[]>({
    queryKey: ['/api/admin/teams/pending'],
    enabled: isAuthenticated,
  });

  const { data: allTeams, isLoading: allTeamsLoading } = useQuery<TeamWithParticipants[]>({
    queryKey: ['/api/admin/teams'],
    enabled: isAuthenticated,
  });

  const { data: supportTickets, isLoading: ticketsLoading } = useQuery<SupportTicket[]>({
    queryKey: ['/api/admin/support/tickets'],
    enabled: isAuthenticated,
  });

  const reviewTeamMutation = useMutation({
    mutationFn: async ({ teamId, action, rejectionReason }: { teamId: string; action: 'approve' | 'reject'; rejectionReason?: string }) => {
      const response = await apiRequest('POST', '/api/admin/teams/review', { teamId, action, rejectionReason });
      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/teams/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/teams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: `Team ${variables.action}d successfully`,
        description: `Registration ${variables.action === 'approve' ? 'approved' : 'rejected'}`,
        variant: variables.action === 'approve' ? 'default' : 'destructive',
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Action Failed",
        description: error.message || "Failed to process team review",
      });
    },
  });

  const replyToTicketMutation = useMutation({
    mutationFn: async ({ ticketId, reply }: { ticketId: string; reply: string }) => {
      const response = await apiRequest('POST', '/api/admin/support/tickets/reply', { ticketId, reply });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/support/tickets'] });
      toast({
        title: "Reply sent successfully",
        description: "The customer will receive your reply via email",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Reply Failed",
        description: error.message || "Failed to send reply",
      });
    },
  });

  const closeTicketMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const response = await apiRequest('POST', `/api/admin/support/tickets/${ticketId}/close`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/support/tickets'] });
      toast({
        title: "Ticket closed",
        description: "Support ticket has been marked as closed",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Close Failed",
        description: error.message || "Failed to close ticket",
      });
    },
  });

  const handleTeamAction = (teamId: string, action: 'approve' | 'reject', rejectionReason?: string) => {
    reviewTeamMutation.mutate({ teamId, action, rejectionReason });
  };

  const handleTicketReply = (ticketId: string, reply: string) => {
    replyToTicketMutation.mutate({ ticketId, reply });
  };

  const handleTicketClose = (ticketId: string) => {
    closeTicketMutation.mutate(ticketId);
  };

  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-500"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="border-green-500 text-green-500"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="border-red-500 text-red-500"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (!isAuthenticated) {
    return <AdminLogin onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-gaming-gradient">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gaming-cyan/10 to-gaming-purple/10"></div>
        <div className="relative container mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row items-center sm:justify-between gap-4">
            <Link href="/" className="flex items-center space-x-2 text-gaming-cyan hover:text-gaming-cyan/80 transition-colors" data-testid="link-home">
              <ArrowLeft size={20} />
              <span>Back to Home</span>
            </Link>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-3 mb-2">
                <Shield className="text-gaming-cyan" size={32} />
                <h1 className="font-orbitron text-2xl sm:text-3xl font-bold text-gradient">ADMIN PANEL</h1>
              </div>
              <p className="text-slate-400 text-sm sm:text-base">Tournament registration management</p>
            </div>
            <div className="hidden sm:block sm:w-32"></div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 py-6 sm:py-8 max-w-6xl">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-gaming-cyan mb-2" data-testid="text-total-teams">
                {stats?.totalTeams || 0}
              </div>
              <div className="text-sm text-slate-400">APPROVED TEAMS</div>
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-yellow-500 mb-2" data-testid="text-pending-teams">
                {stats?.pendingTeams || 0}
              </div>
              <div className="text-sm text-slate-400">PENDING REVIEW</div>
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-red-500 mb-2" data-testid="text-rejected-teams">
                {stats?.rejectedTeams || 0}
              </div>
              <div className="text-sm text-slate-400">REJECTED</div>
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-gaming-purple mb-2" data-testid="text-total-players">
                {stats?.totalPlayers || 0}
              </div>
              <div className="text-sm text-slate-400">TOTAL PLAYERS</div>
            </CardContent>
          </Card>
        </div>

        {/* Team Management Tabs */}
        <Card className="card-glow border-0">
          <CardHeader>
            <CardTitle className="font-orbitron text-gaming-cyan">TEAM MANAGEMENT</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 mb-6 text-xs sm:text-sm">
                <TabsTrigger value="pending" className="data-[state=active]:bg-yellow-500/20 data-[state=active]:text-yellow-500">
                  Pending Review ({stats?.pendingTeams || 0})
                </TabsTrigger>
                <TabsTrigger value="approved" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-500">
                  Approved ({stats?.totalTeams || 0})
                </TabsTrigger>
                <TabsTrigger value="support" className="data-[state=active]:bg-gaming-purple/20 data-[state=active]:text-gaming-purple">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Support ({supportTickets?.filter(t => t.status !== 'closed').length || 0})
                </TabsTrigger>
                <TabsTrigger value="all" className="data-[state=active]:bg-gaming-cyan/20 data-[state=active]:text-gaming-cyan">
                  All Teams
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pending">
                {pendingLoading ? (
                  <div className="text-center py-8">
                    <div className="text-slate-400">Loading pending teams...</div>
                  </div>
                ) : pendingTeams && pendingTeams.length > 0 ? (
                  <div className="space-y-4">
                    {pendingTeams.map((team) => (
                      <TeamReviewCard 
                        key={team.id} 
                        team={team} 
                        onAction={handleTeamAction}
                        isLoading={reviewTeamMutation.isPending}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <p className="text-slate-400 text-lg">No pending teams to review</p>
                    <p className="text-slate-500 text-sm">All registrations have been processed</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="approved">
                {allTeamsLoading ? (
                  <div className="text-center py-8">
                    <div className="text-slate-400">Loading approved teams...</div>
                  </div>
                ) : (
                  <TeamList teams={allTeams?.filter(team => team.status === 'approved') || []} />
                )}
              </TabsContent>

              <TabsContent value="support">
                {ticketsLoading ? (
                  <div className="text-center py-8">
                    <div className="text-slate-400">Loading support tickets...</div>
                  </div>
                ) : supportTickets && supportTickets.length > 0 ? (
                  <div className="space-y-4">
                    {supportTickets.map((ticket) => (
                      <SupportTicketCard 
                        key={ticket.id} 
                        ticket={ticket} 
                        onReply={handleTicketReply}
                        onClose={handleTicketClose}
                        isLoading={replyToTicketMutation.isPending || closeTicketMutation.isPending}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <MessageCircle className="w-16 h-16 text-gaming-purple mx-auto mb-4" />
                    <p className="text-slate-400 text-lg">No support tickets</p>
                    <p className="text-slate-500 text-sm">Customer inquiries will appear here</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="all">
                {allTeamsLoading ? (
                  <div className="text-center py-8">
                    <div className="text-slate-400">Loading all teams...</div>
                  </div>
                ) : (
                  <TeamList teams={allTeams || []} showStatus />
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

interface TeamReviewCardProps {
  team: TeamWithParticipants;
  onAction: (teamId: string, action: 'approve' | 'reject', rejectionReason?: string) => void;
  isLoading: boolean;
}

function TeamReviewCard({ team, onAction, isLoading }: TeamReviewCardProps) {
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");

  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const captain = team.participants.find(p => p.isCaptain === 1);

  return (
    <div className="bg-slate-800/30 rounded-xl p-6 border border-slate-700/50" data-testid={`card-team-review-${team.id}`}>
      <div className="space-y-4">
        {/* Team Info */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <h3 className="font-orbitron text-xl font-bold text-white" data-testid={`text-team-name-${team.id}`}>
              {team.name}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-slate-400">
              <span className="text-gaming-purple">{formatTournamentName(team.tournament)}</span>
              <span>•</span>
              <span className="text-gaming-green">{formatLevelName(team.level)}</span>
              <span>•</span>
              <span className="text-gaming-cyan">{team.registrationId}</span>
            </div>
          </div>
          <Badge variant="outline" className="border-yellow-500 text-yellow-500">
            <Clock className="w-3 h-3 mr-1" />
            PENDING REVIEW
          </Badge>
        </div>

        {/* Team Members */}
        <div className="grid md:grid-cols-2 gap-3">
          {team.participants.map((member, index) => (
            <div key={member.id} className="bg-slate-700/30 rounded-lg p-3" data-testid={`card-member-${team.id}-${index}`}>
              <div className="flex items-center space-x-2">
                <User className="text-gaming-cyan" size={14} />
                <span className="font-semibold text-sm" data-testid={`text-member-name-${team.id}-${index}`}>
                  {member.name}
                </span>
                {member.isCaptain === 1 && (
                  <Crown className="text-yellow-500" size={12} />
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1" data-testid={`text-member-uid-${team.id}-${index}`}>
                UID: {member.uid}
              </p>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3 pt-4 border-t border-slate-700">
          <Button
            onClick={() => onAction(team.id, 'approve')}
            disabled={isLoading}
            className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold"
            data-testid={`button-approve-${team.id}`}
          >
            <CheckCircle className="mr-2" size={16} />
            Approve
          </Button>
          
          <Button
            onClick={() => setShowRejectForm(!showRejectForm)}
            disabled={isLoading}
            variant="outline"
            className="px-6 py-2 border-red-500 text-red-500 hover:bg-red-500/10"
            data-testid={`button-reject-${team.id}`}
          >
            <XCircle className="mr-2" size={16} />
            Reject
          </Button>

          <div className="text-xs text-slate-500">
            Registered: {new Date(team.createdAt).toLocaleDateString()}
          </div>
        </div>

        {/* Rejection Form */}
        {showRejectForm && (
          <div className="mt-4 p-4 bg-red-500/10 rounded-lg border border-red-500/30">
            <label className="block text-sm font-semibold text-red-400 mb-2">
              Rejection Reason (Optional)
            </label>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="Enter reason for rejection..."
              className="w-full p-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-400 resize-none"
              rows={3}
              data-testid={`input-rejection-reason-${team.id}`}
            />
            <div className="flex items-center space-x-2 mt-3">
              <Button
                onClick={() => {
                  onAction(team.id, 'reject', rejectionReason);
                  setShowRejectForm(false);
                  setRejectionReason("");
                }}
                disabled={isLoading}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm"
                data-testid={`button-confirm-reject-${team.id}`}
              >
                Confirm Rejection
              </Button>
              <Button
                onClick={() => {
                  setShowRejectForm(false);
                  setRejectionReason("");
                }}
                variant="ghost"
                className="px-4 py-2 text-slate-400 hover:text-white text-sm"
                data-testid={`button-cancel-reject-${team.id}`}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

interface TeamListProps {
  teams: TeamWithParticipants[];
  showStatus?: boolean;
}

function TeamList({ teams, showStatus = false }: TeamListProps) {
  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-500"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="border-green-500 text-green-500"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="border-red-500 text-red-500"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (teams.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400 text-lg">No teams found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {teams.map((team) => (
        <div key={team.id} className="bg-slate-800/30 rounded-xl p-4 border border-slate-700/50" data-testid={`card-team-${team.id}`}>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h4 className="font-semibold text-white" data-testid={`text-team-name-${team.id}`}>
                {team.name}
              </h4>
              <div className="flex items-center space-x-3 text-sm text-slate-400">
                <span>{formatTournamentName(team.tournament)}</span>
                <span>•</span>
                <span>{formatLevelName(team.level)}</span>
                <span>•</span>
                <span>{team.participants.length} members</span>
                <span>•</span>
                <span className="text-gaming-cyan">{team.registrationId}</span>
              </div>
            </div>
            <div className="text-right space-y-2">
              {showStatus && getStatusBadge(team.status)}
              <p className="text-xs text-slate-500">
                {new Date(team.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
          
          {team.status === 'rejected' && team.rejectionReason && (
            <div className="mt-3 p-3 bg-red-500/10 rounded-lg border border-red-500/30">
              <p className="text-red-400 text-sm">
                <strong>Rejection Reason:</strong> {team.rejectionReason}
              </p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

interface SupportTicketCardProps {
  ticket: SupportTicket;
  onReply: (ticketId: string, reply: string) => void;
  onClose: (ticketId: string) => void;
  isLoading: boolean;
}

function SupportTicketCard({ ticket, onReply, onClose, isLoading }: SupportTicketCardProps) {
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [replyMessage, setReplyMessage] = useState("");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-500"><Clock className="w-3 h-3 mr-1" />Open</Badge>;
      case 'replied':
        return <Badge variant="outline" className="border-blue-500 text-blue-500"><Reply className="w-3 h-3 mr-1" />Replied</Badge>;
      case 'closed':
        return <Badge variant="outline" className="border-gray-500 text-gray-500"><XCircle className="w-3 h-3 mr-1" />Closed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleString();
  };

  return (
    <div className="bg-slate-800/30 rounded-xl p-6 border border-slate-700/50" data-testid={`card-ticket-${ticket.id}`}>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              <h3 className="font-semibold text-white text-lg" data-testid={`text-ticket-subject-${ticket.id}`}>
                {ticket.subject}
              </h3>
              {getStatusBadge(ticket.status)}
            </div>
            <div className="flex items-center space-x-4 text-sm text-slate-400">
              <span className="flex items-center">
                <User className="w-4 h-4 mr-1" />
                {ticket.name}
              </span>
              <span className="flex items-center">
                <Mail className="w-4 h-4 mr-1" />
                {ticket.email}
              </span>
              <span>{formatDate(ticket.createdAt)}</span>
            </div>
          </div>
          
          <div className="flex space-x-2">
            {ticket.status !== 'closed' && (
              <>
                <Button
                  onClick={() => setShowReplyForm(!showReplyForm)}
                  variant="outline"
                  size="sm"
                  className="bg-gaming-purple/20 border-gaming-purple text-gaming-purple hover:bg-gaming-purple/30"
                  data-testid={`button-reply-${ticket.id}`}
                >
                  <Reply className="w-4 h-4 mr-2" />
                  Reply
                </Button>
                <Button
                  onClick={() => onClose(ticket.id)}
                  disabled={isLoading}
                  variant="outline"
                  size="sm"
                  className="bg-slate-600/20 border-slate-600 text-slate-400 hover:bg-slate-600/30"
                  data-testid={`button-close-${ticket.id}`}
                >
                  Close
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Message */}
        <div className="bg-slate-700/30 rounded-lg p-4">
          <h4 className="text-sm font-semibold text-slate-300 mb-2">Customer Message:</h4>
          <p className="text-slate-300 text-sm leading-relaxed" data-testid={`text-ticket-message-${ticket.id}`}>
            {ticket.message}
          </p>
        </div>

        {/* Admin Reply */}
        {ticket.adminReply && (
          <div className="bg-gaming-purple/10 rounded-lg p-4 border border-gaming-purple/30">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold text-gaming-purple">Admin Reply:</h4>
              <span className="text-xs text-slate-400">
                {ticket.repliedAt && formatDate(ticket.repliedAt)}
              </span>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed" data-testid={`text-ticket-reply-${ticket.id}`}>
              {ticket.adminReply}
            </p>
          </div>
        )}

        {/* Reply Form */}
        {showReplyForm && (
          <div className="bg-slate-700/20 rounded-lg p-4 border border-slate-600/50">
            <h4 className="text-sm font-semibold text-white mb-3">Send Reply:</h4>
            <div className="space-y-3">
              <textarea
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder="Type your reply here..."
                rows={4}
                className="w-full bg-slate-800/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400 focus:border-gaming-purple focus:ring-1 focus:ring-gaming-purple/20 text-sm resize-none"
                data-testid={`textarea-reply-${ticket.id}`}
              />
              <div className="flex space-x-2">
                <Button
                  onClick={() => {
                    if (replyMessage.trim()) {
                      onReply(ticket.id, replyMessage);
                      setReplyMessage("");
                      setShowReplyForm(false);
                    }
                  }}
                  disabled={isLoading || !replyMessage.trim()}
                  className="px-4 py-2 btn-gaming text-white text-sm"
                  data-testid={`button-send-reply-${ticket.id}`}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Reply
                </Button>
                <Button
                  onClick={() => {
                    setShowReplyForm(false);
                    setReplyMessage("");
                  }}
                  variant="ghost"
                  className="px-4 py-2 text-slate-400 hover:text-white text-sm"
                  data-testid={`button-cancel-reply-${ticket.id}`}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}