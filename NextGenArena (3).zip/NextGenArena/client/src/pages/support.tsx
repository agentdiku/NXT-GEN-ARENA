import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, MessageCircle, Mail, User, Send, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { supportTicketSchema, type SupportTicketSubmission } from "@shared/schema";

export default function Support() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<SupportTicketSubmission>({
    resolver: zodResolver(supportTicketSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  const submitTicketMutation = useMutation({
    mutationFn: async (data: SupportTicketSubmission) => {
      const response = await apiRequest('POST', '/api/support/tickets', data);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      form.reset();
      toast({
        title: "Support Ticket Submitted!",
        description: "Your inquiry has been received. We'll respond via email soon.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: error.message || "Failed to submit ticket. Please try again.",
      });
    },
  });

  const handleSubmit = (data: SupportTicketSubmission) => {
    submitTicketMutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gaming-gradient py-6 sm:py-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 space-y-6 sm:space-y-8">
          <Card className="card-glow border-0">
            <CardContent className="p-8 text-center space-y-6">
              <div className="w-20 h-20 mx-auto bg-gradient-to-br from-gaming-green/20 to-gaming-green/5 rounded-full flex items-center justify-center">
                <CheckCircle className="text-gaming-green" size={40} />
              </div>
              <h1 className="font-orbitron text-2xl sm:text-3xl font-bold text-gaming-green">
                TICKET SUBMITTED SUCCESSFULLY!
              </h1>
              <p className="text-slate-300 text-base sm:text-lg">
                Your support request has been received. Our team will review your inquiry and respond via email within 24 hours.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-3 btn-gaming text-white font-bold w-full sm:w-auto"
                  data-testid="button-submit-another"
                >
                  SUBMIT ANOTHER TICKET
                </Button>
                <Link href="/">
                  <Button 
                    variant="outline"
                    className="px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white border-slate-600 w-full sm:w-auto"
                    data-testid="button-back-home"
                  >
                    <ArrowLeft className="mr-2" size={16} />
                    BACK TO HOME
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gaming-gradient py-6 sm:py-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 space-y-6 sm:space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="font-orbitron text-3xl sm:text-4xl font-bold text-gradient">
            SUPPORT CENTER
          </h1>
          <p className="text-slate-300 text-base sm:text-lg">
            Need help? Submit a support ticket and our team will assist you
          </p>
        </div>

        {/* Support Form */}
        <Card className="card-glow border-0">
          <CardContent className="p-6 sm:p-8">
            <div className="space-y-6">
              <div className="text-center">
                <h2 className="font-orbitron text-2xl font-bold text-gaming-cyan flex items-center justify-center">
                  <MessageCircle className="mr-3" size={28} />
                  SUBMIT A SUPPORT TICKET
                </h2>
                <p className="text-slate-400 text-sm mt-2">
                  Fill out the form below and we'll get back to you via email
                </p>
              </div>

              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                {/* Name */}
                <div>
                  <Label className="block text-sm font-semibold text-slate-300 mb-2">
                    <User className="inline mr-2 text-gaming-cyan" size={16} />
                    YOUR NAME
                  </Label>
                  <Input
                    placeholder="Enter your full name"
                    className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20"
                    {...form.register('name')}
                    data-testid="input-support-name"
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.name.message}</p>
                  )}
                </div>

                {/* Email */}
                <div>
                  <Label className="block text-sm font-semibold text-slate-300 mb-2">
                    <Mail className="inline mr-2 text-gaming-cyan" size={16} />
                    EMAIL ADDRESS
                  </Label>
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20"
                    {...form.register('email')}
                    data-testid="input-support-email"
                  />
                  {form.formState.errors.email && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.email.message}</p>
                  )}
                </div>

                {/* Subject */}
                <div>
                  <Label className="block text-sm font-semibold text-slate-300 mb-2">
                    SUBJECT
                  </Label>
                  <Input
                    placeholder="What is this about?"
                    className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20"
                    {...form.register('subject')}
                    data-testid="input-support-subject"
                  />
                  {form.formState.errors.subject && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.subject.message}</p>
                  )}
                </div>

                {/* Message */}
                <div>
                  <Label className="block text-sm font-semibold text-slate-300 mb-2">
                    MESSAGE
                  </Label>
                  <Textarea
                    placeholder="Describe your issue or question in detail..."
                    rows={6}
                    className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20 resize-none"
                    {...form.register('message')}
                    data-testid="textarea-support-message"
                  />
                  {form.formState.errors.message && (
                    <p className="text-red-400 text-sm mt-1">{form.formState.errors.message.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <div className="text-center">
                  <Button
                    type="submit"
                    disabled={submitTicketMutation.isPending}
                    className="px-12 py-4 btn-gaming text-white font-bold text-lg rounded-xl"
                    data-testid="button-submit-ticket"
                  >
                    {submitTicketMutation.isPending ? (
                      "SUBMITTING..."
                    ) : (
                      <>
                        <Send className="mr-2" size={16} />
                        SUBMIT TICKET
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <Card className="card-glow border-0">
          <CardContent className="p-6">
            <h3 className="font-orbitron text-xl font-bold text-white mb-4 text-center">
              COMMON QUESTIONS
            </h3>
            <div className="space-y-4 text-sm">
              <div className="bg-slate-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-gaming-cyan mb-2">How do I check my registration status?</h4>
                <p className="text-slate-300">
                  After registration, you'll receive a confirmation email with your team's registration ID. 
                  The admin will review and approve teams before the tournament.
                </p>
              </div>
              <div className="bg-slate-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-gaming-cyan mb-2">What devices are supported?</h4>
                <p className="text-slate-300">
                  Any mobile device capable of running Free Fire or PUBG Mobile smoothly. 
                  You must bring your own device and ensure stable internet connectivity.
                </p>
              </div>
              <div className="bg-slate-800/30 rounded-lg p-4">
                <h4 className="font-semibold text-gaming-cyan mb-2">When will I hear back about my ticket?</h4>
                <p className="text-slate-300">
                  Our support team responds to all tickets within 24 hours via the email address you provide.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="text-center">
          <Link href="/">
            <Button 
              className="px-8 py-3 btn-gaming text-white font-bold"
              data-testid="button-back-home"
            >
              <ArrowLeft className="mr-2" size={16} />
              BACK TO REGISTRATION
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}