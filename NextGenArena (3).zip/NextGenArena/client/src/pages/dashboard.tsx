import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Trophy, Users, Gamepad2, GraduationCap, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { TeamWithParticipants } from "@shared/schema";

interface TournamentStats {
  totalTeams: number;
  totalPlayers: number;
  freeFireTeams: number;
  pubgTeams: number;
  firstPUTeams: number;
  secondPUTeams: number;
}

export default function Dashboard() {
  const { data: allTeams, isLoading: teamsLoading } = useQuery<TeamWithParticipants[]>({
    queryKey: ['/api/teams'],
  });

  // Filter to show only approved teams
  const teams = allTeams?.filter(team => team.status === 'approved') || [];

  const { data: stats, isLoading: statsLoading } = useQuery<TournamentStats>({
    queryKey: ['/api/stats'],
  });

  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const getTournamentIcon = (tournament: string) => {
    return tournament === 'freefire' ? (
      <div className="w-12 h-12 bg-gaming-cyan/20 rounded-xl flex items-center justify-center">
        <Trophy className="text-gaming-cyan" size={24} />
      </div>
    ) : (
      <div className="w-12 h-12 bg-gaming-purple/20 rounded-xl flex items-center justify-center">
        <Gamepad2 className="text-gaming-purple" size={24} />
      </div>
    );
  };

  const getLevelIcon = (level: string) => {
    return level === '1st-pu' ? (
      <User className="text-gaming-green" size={16} />
    ) : (
      <GraduationCap className="text-gaming-green" size={16} />
    );
  };

  return (
    <div className="min-h-screen bg-gaming-gradient">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gaming-cyan/10 to-gaming-purple/10"></div>
        <div className="relative container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2 text-gaming-cyan hover:text-gaming-cyan/80 transition-colors" data-testid="link-home">
              <ArrowLeft size={20} />
              <span>Back to Registration</span>
            </Link>
            <div className="text-center">
              <h1 className="font-orbitron text-3xl font-bold text-gradient">TOURNAMENT DASHBOARD</h1>
              <p className="text-slate-400">Overview of registered teams and tournament status</p>
            </div>
            <div className="w-32"></div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8 max-w-6xl">
        {/* Statistics Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-16 mx-auto mb-2 bg-slate-700" />
              ) : (
                <div className="text-3xl font-bold text-gaming-cyan mb-2" data-testid="text-total-teams">
                  {stats?.totalTeams || 0}
                </div>
              )}
              <div className="text-sm text-slate-400">REGISTERED TEAMS</div>
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              {statsLoading ? (
                <Skeleton className="h-8 w-16 mx-auto mb-2 bg-slate-700" />
              ) : (
                <div className="text-3xl font-bold text-gaming-purple mb-2" data-testid="text-total-players">
                  {stats?.totalPlayers || 0}
                </div>
              )}
              <div className="text-sm text-slate-400">TOTAL PLAYERS</div>
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-gaming-green mb-2">∞</div>
              <div className="text-sm text-slate-400">TOURNAMENT EXCITEMENT</div>
            </CardContent>
          </Card>
        </div>

        {/* Tournament Breakdown */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="card-glow border-0">
            <CardHeader>
              <CardTitle className="font-orbitron text-gaming-cyan">Tournament Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {statsLoading ? (
                <>
                  <Skeleton className="h-4 w-full bg-slate-700" />
                  <Skeleton className="h-4 w-full bg-slate-700" />
                </>
              ) : (
                <>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Free Fire Teams:</span>
                    <span className="font-semibold text-gaming-cyan" data-testid="text-freefire-teams">
                      {stats?.freeFireTeams || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">PUBG Teams:</span>
                    <span className="font-semibold text-gaming-purple" data-testid="text-pubg-teams">
                      {stats?.pubgTeams || 0}
                    </span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="card-glow border-0">
            <CardHeader>
              <CardTitle className="font-orbitron text-gaming-green">Academic Level Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {statsLoading ? (
                <>
                  <Skeleton className="h-4 w-full bg-slate-700" />
                  <Skeleton className="h-4 w-full bg-slate-700" />
                </>
              ) : (
                <>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">1st PU Teams:</span>
                    <span className="font-semibold text-gaming-green" data-testid="text-first-pu-teams">
                      {stats?.firstPUTeams || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">2nd PU Teams:</span>
                    <span className="font-semibold text-gaming-green" data-testid="text-second-pu-teams">
                      {stats?.secondPUTeams || 0}
                    </span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Registered Teams */}
        <Card className="card-glow border-0">
          <CardHeader>
            <CardTitle className="font-orbitron text-gaming-cyan">REGISTERED TEAMS</CardTitle>
          </CardHeader>
          <CardContent>
            {teamsLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="p-4 bg-slate-800/30 rounded-xl border border-slate-700/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <Skeleton className="w-12 h-12 rounded-xl bg-slate-700" />
                        <div>
                          <Skeleton className="h-4 w-32 mb-2 bg-slate-700" />
                          <Skeleton className="h-3 w-48 bg-slate-700" />
                        </div>
                      </div>
                      <div className="text-right">
                        <Skeleton className="h-3 w-20 mb-1 bg-slate-700" />
                        <Skeleton className="h-3 w-16 bg-slate-700" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : teams && teams.length > 0 ? (
              <div className="space-y-4">
                {teams.map((team) => (
                  <div key={team.id} className="p-4 bg-slate-800/30 rounded-xl border border-slate-700/50 hover:border-gaming-cyan/30 transition-colors" data-testid={`card-team-${team.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        {getTournamentIcon(team.tournament)}
                        <div>
                          <p className="font-semibold text-white" data-testid={`text-team-name-${team.id}`}>{team.name}</p>
                          <div className="flex items-center space-x-2 text-sm text-slate-400">
                            <span>{formatTournamentName(team.tournament)}</span>
                            <span>•</span>
                            <div className="flex items-center space-x-1">
                              {getLevelIcon(team.level)}
                              <span>{formatLevelName(team.level)}</span>
                            </div>
                            <span>•</span>
                            <div className="flex items-center space-x-1">
                              <Users size={14} />
                              <span>{team.participants.length} members</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="border-gaming-green text-gaming-green mb-1" data-testid={`text-registration-id-${team.id}`}>
                          {team.registrationId}
                        </Badge>
                        <p className="text-xs text-slate-400">
                          {new Date(team.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Trophy className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400 text-lg mb-2">No teams registered yet</p>
                <p className="text-slate-500 text-sm">Be the first to register your team!</p>
                <Link href="/" className="inline-block mt-4 btn-gaming px-6 py-2 rounded-xl text-white font-semibold hover:scale-105 transition-transform" data-testid="button-register-first-team">
                  Register First Team
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
