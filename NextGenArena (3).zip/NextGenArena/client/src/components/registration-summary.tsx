import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Trophy, Users, Flag, Eye, RotateCcw, User } from "lucide-react";
import type { TeamWithParticipants } from "@shared/schema";

interface RegistrationSummaryProps {
  team: TeamWithParticipants;
  onReset: () => void;
  onViewDashboard: () => void;
}

export default function RegistrationSummary({ team, onReset, onViewDashboard }: RegistrationSummaryProps) {
  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const captain = team.participants.find(p => p.isCaptain === 1);

  return (
    <div className="space-y-8">
      <h2 className="text-center font-orbitron text-3xl font-bold text-gradient mb-8">
        REGISTRATION SUMMARY
      </h2>
      
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Registration Success Card */}
        <Card className="card-glow border-0">
          <CardContent className="p-8">
            <div className="space-y-6">
              <div className="text-center pb-6 border-b border-slate-700">
                <div className="w-20 h-20 mx-auto bg-gradient-to-br from-gaming-green/20 to-gaming-green/5 rounded-full flex items-center justify-center mb-4">
                  <Check className="text-3xl text-gaming-green" size={40} />
                </div>
                <h3 className="font-orbitron text-2xl font-bold text-gaming-green mb-2">REGISTRATION SUBMITTED!</h3>
                <p className="text-slate-400">Your team registration is pending admin approval</p>
              </div>

              {/* Tournament Details */}
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="font-orbitron font-bold text-gaming-cyan text-lg">TOURNAMENT DETAILS</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Game:</span>
                      <span className="font-semibold text-gaming-purple" data-testid="text-summary-tournament">
                        {formatTournamentName(team.tournament)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Category:</span>
                      <span className="font-semibold text-gaming-green" data-testid="text-summary-level">
                        {formatLevelName(team.level)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Registration ID:</span>
                      <span className="font-semibold text-gaming-cyan" data-testid="text-summary-registration-id">
                        {team.registrationId}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Status:</span>
                      <Badge className="bg-yellow-500/20 text-yellow-500 border-yellow-500/30">
                        PENDING APPROVAL
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-orbitron font-bold text-gaming-cyan text-lg">TEAM INFORMATION</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Team Name:</span>
                      <span className="font-semibold" data-testid="text-summary-team-name">{team.name}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Members:</span>
                      <span className="font-semibold" data-testid="text-summary-member-count">
                        {team.participants.length} Players
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Captain:</span>
                      <span className="font-semibold text-gaming-cyan" data-testid="text-summary-captain">
                        {captain?.name || 'Not assigned'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Registered:</span>
                      <span className="font-semibold text-slate-300">
                        {new Date(team.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Team Roster */}
              <div className="pt-6 border-t border-slate-700">
                <h4 className="font-orbitron font-bold text-gaming-purple text-lg mb-4">REGISTERED PLAYERS</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  {team.participants.map((member, index) => (
                    <div key={member.id} className="bg-slate-800/30 rounded-lg p-4 border border-slate-700/50" data-testid={`card-player-${index}`}>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gaming-cyan/20 rounded-full flex items-center justify-center">
                          <User className="text-gaming-cyan text-sm" size={16} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="font-semibold text-sm" data-testid={`text-player-name-${index}`}>
                              {member.name}
                            </p>
                            {member.isCaptain === 1 && (
                              <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-500">
                                CAPTAIN
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-slate-400" data-testid={`text-player-uid-${index}`}>
                            UID: {member.uid}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={onViewDashboard}
            className="px-8 py-3 btn-gaming text-white font-bold"
            data-testid="button-view-dashboard"
          >
            <Eye className="mr-2" size={16} />
            VIEW TOURNAMENT DASHBOARD
          </Button>
          
          <Button
            onClick={onReset}
            variant="outline"
            className="px-8 py-3 bg-slate-700 hover:bg-slate-600 text-white border-slate-600"
            data-testid="button-register-another"
          >
            <RotateCcw className="mr-2" size={16} />
            REGISTER ANOTHER TEAM
          </Button>
        </div>
      </div>
    </div>
  );
}