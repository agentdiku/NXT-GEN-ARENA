import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gamepad2, Trophy, Users, Clock, Flag, GraduationCap, User, Check, ArrowLeft, ArrowRight } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import TeamForm from "./team-form";
import RegistrationSummary from "./registration-summary";
import type { TeamRegistration, TeamWithParticipants } from "@shared/schema";
import freeFireLogo from "@assets/image_1755677914827.png";
import pubgLogo from "@assets/image_1755677943434.png";

export default function TournamentWizard() {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedTournament, setSelectedTournament] = useState<string>("");
  const [selectedLevel, setSelectedLevel] = useState<string>("");
  const [teamData, setTeamData] = useState<Omit<TeamRegistration, 'tournament' | 'level'>>({
    teamName: "",
    participants: [],
  });
  const [registeredTeam, setRegisteredTeam] = useState<TeamWithParticipants | null>(null);
  
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  const totalSteps = 4;

  const registerTeamMutation = useMutation({
    mutationFn: async (data: TeamRegistration) => {
      const response = await apiRequest('POST', '/api/teams/register', data);
      return response.json();
    },
    onSuccess: (data: TeamWithParticipants) => {
      setRegisteredTeam(data);
      setCurrentStep(4);
      queryClient.invalidateQueries({ queryKey: ['/api/teams'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Registration Successful!",
        description: `Team "${data.name}" has been registered with ID: ${data.registrationId}`,
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: error.message || "Failed to register team. Please try again.",
      });
    },
  });

  const handleTournamentSelect = (tournament: string) => {
    setSelectedTournament(tournament);
    setTimeout(() => {
      setCurrentStep(2);
    }, 800);
  };

  const handleLevelSelect = (level: string) => {
    setSelectedLevel(level);
    setTimeout(() => {
      setCurrentStep(3);
    }, 800);
  };

  const handleTeamSubmit = (data: Omit<TeamRegistration, 'tournament' | 'level'>) => {
    setTeamData(data);
    const registrationData: TeamRegistration = {
      ...data,
      tournament: selectedTournament as "freefire" | "pubg",
      level: selectedLevel as "1st-pu" | "2nd-pu",
    };
    registerTeamMutation.mutate(registrationData);
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const previousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const resetWizard = () => {
    setCurrentStep(1);
    setSelectedTournament("");
    setSelectedLevel("");
    setTeamData({ teamName: "", participants: [] });
    setRegisteredTeam(null);
  };

  const ProgressIndicator = () => (
    <Card className="card-glow border-0">
      <CardContent className="p-6">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 mb-4">
          <span className="text-sm font-semibold text-slate-300">REGISTRATION PROGRESS</span>
          <span className="text-sm text-gaming-cyan font-bold" data-testid="text-current-step">
            STEP {currentStep} OF {totalSteps}
          </span>
        </div>
        <div className="flex space-x-2">
          {Array.from({ length: totalSteps }).map((_, index) => (
            <div
              key={index}
              className={`flex-1 h-2 rounded-full ${
                index < currentStep
                  ? 'bg-gradient-to-r from-gaming-cyan to-gaming-purple'
                  : 'bg-slate-700'
              }`}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const TournamentSelection = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
      <h2 className="col-span-full text-center font-orbitron text-2xl sm:text-3xl font-bold text-gradient mb-8">
        CHOOSE YOUR BATTLEGROUND
      </h2>
      
      {/* Free Fire Card */}
      <Card 
        className={`card-glow border-0 cursor-pointer transition-all duration-300 hover:shadow-glow-cyan hover:border-gaming-cyan/50 group ${
          selectedTournament === 'freefire' ? 'ring-2 ring-gaming-cyan' : ''
        }`}
        onClick={() => handleTournamentSelect('freefire')}
        data-testid="card-tournament-freefire"
      >
        <CardContent className="p-8">
          <div className="text-center space-y-6">
            <div className="relative mx-auto w-32 h-32 rounded-xl overflow-hidden bg-gradient-to-br from-gaming-cyan/20 to-gaming-cyan/5 flex items-center justify-center">
              <img 
                src={freeFireLogo} 
                alt="Free Fire" 
                className="w-28 h-20 object-contain group-hover:scale-110 transition-transform duration-500"
              />
            </div>
            <div>
              <h3 className="font-orbitron text-2xl font-bold text-gaming-cyan mb-2">FREE FIRE</h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                Battle Royale tournament featuring intense 50-player matches with strategic gameplay and tactical combat.
              </p>
              <div className="mt-4 flex justify-center space-x-4 text-xs text-slate-400">
                <span><Users className="inline w-3 h-3 mr-1" />4 Players/Team</span>
                <span><Clock className="inline w-3 h-3 mr-1" />15-20 min</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PUBG Card */}
      <Card 
        className={`card-glow border-0 cursor-pointer transition-all duration-300 hover:shadow-glow-purple hover:border-gaming-purple/50 group ${
          selectedTournament === 'pubg' ? 'ring-2 ring-gaming-purple' : ''
        }`}
        onClick={() => handleTournamentSelect('pubg')}
        data-testid="card-tournament-pubg"
      >
        <CardContent className="p-8">
          <div className="text-center space-y-6">
            <div className="relative mx-auto w-32 h-32 rounded-xl overflow-hidden bg-gradient-to-br from-gaming-purple/20 to-gaming-purple/5 flex items-center justify-center">
              <img 
                src={pubgLogo} 
                alt="PUBG Mobile" 
                className="w-28 h-20 object-contain group-hover:scale-110 transition-transform duration-500"
              />
            </div>
            <div>
              <h3 className="font-orbitron text-2xl font-bold text-gaming-purple mb-2">PUBG MOBILE</h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                Classic Battle Royale experience with 100-player lobbies, realistic combat mechanics, and diverse battlegrounds.
              </p>
              <div className="mt-4 flex justify-center space-x-4 text-xs text-slate-400">
                <span><Users className="inline w-3 h-3 mr-1" />4 Players/Team</span>
                <span><Clock className="inline w-3 h-3 mr-1" />25-30 min</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const LevelSelection = () => (
    <div className="space-y-8">
      <h2 className="text-center font-orbitron text-2xl sm:text-3xl font-bold text-gradient mb-8">
        SELECT YOUR ACADEMIC LEVEL
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 max-w-4xl mx-auto">
        {/* 1st PU */}
        <Card 
          className={`card-glow border-0 cursor-pointer transition-all duration-300 hover:shadow-glow-green hover:border-gaming-green/50 group ${
            selectedLevel === '1st-pu' ? 'ring-2 ring-gaming-green' : ''
          }`}
          onClick={() => handleLevelSelect('1st-pu')}
          data-testid="card-level-1st-pu"
        >
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 mx-auto bg-gradient-to-br from-gaming-green/20 to-gaming-green/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <User className="text-3xl text-gaming-green" size={32} />
              </div>
              <h3 className="font-orbitron text-2xl font-bold text-gaming-green">1ST PU</h3>
              <p className="text-slate-300 text-sm">First Year Pre-University College Students</p>
              <div className="text-xs text-slate-400">
                <span className="mr-2">ℹ️</span>Ages 16-17
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 2nd PU */}
        <Card 
          className={`card-glow border-0 cursor-pointer transition-all duration-300 hover:shadow-glow-green hover:border-gaming-green/50 group ${
            selectedLevel === '2nd-pu' ? 'ring-2 ring-gaming-green' : ''
          }`}
          onClick={() => handleLevelSelect('2nd-pu')}
          data-testid="card-level-2nd-pu"
        >
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 mx-auto bg-gradient-to-br from-gaming-green/20 to-gaming-green/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <GraduationCap className="text-3xl text-gaming-green" size={32} />
              </div>
              <h3 className="font-orbitron text-2xl font-bold text-gaming-green">2ND PU</h3>
              <p className="text-slate-300 text-sm">Second Year Pre-University College Students</p>
              <div className="text-xs text-slate-400">
                <span className="mr-2">ℹ️</span>Ages 17-18
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      <ProgressIndicator />

      {/* Step Content */}
      {currentStep === 1 && <TournamentSelection />}
      {currentStep === 2 && <LevelSelection />}
      {currentStep === 3 && (
        <TeamForm 
          onSubmit={handleTeamSubmit}
          isLoading={registerTeamMutation.isPending}
          tournament={selectedTournament}
          level={selectedLevel}
        />
      )}
      {currentStep === 4 && registeredTeam && (
        <RegistrationSummary 
          team={registeredTeam}
          onReset={resetWizard}
          onViewDashboard={() => navigate('/dashboard')}
        />
      )}

      {/* Navigation Buttons */}
      {currentStep !== 4 && (
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-8">
          <Button
            variant="outline"
            onClick={previousStep}
            disabled={currentStep === 1}
            className="px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white border-slate-600 w-full sm:w-auto"
            data-testid="button-previous"
          >
            <ArrowLeft className="mr-2" size={16} />
            PREVIOUS
          </Button>
          
          <Button
            onClick={nextStep}
            disabled={
              (currentStep === 1 && !selectedTournament) ||
              (currentStep === 2 && !selectedLevel) ||
              currentStep >= totalSteps
            }
            className="px-8 py-3 btn-gaming text-white font-bold w-full sm:w-auto"
            data-testid="button-next"
          >
            NEXT STEP
            <ArrowRight className="ml-2" size={16} />
          </Button>
        </div>
      )}
    </div>
  );
}