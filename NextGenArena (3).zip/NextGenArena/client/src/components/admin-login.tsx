import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Lock, ArrowLeft, Eye, EyeOff } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AdminLoginProps {
  onLogin: () => void;
}

export default function AdminLogin({ onLogin }: AdminLoginProps) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (password: string) => {
      const response = await apiRequest('POST', '/api/admin/login', { password });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Login Successful",
          description: "Welcome to the admin panel",
        });
        onLogin();
      }
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: error.message || "Invalid password",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.trim()) {
      loginMutation.mutate(password);
    }
  };

  return (
    <div className="min-h-screen bg-gaming-gradient flex items-center justify-center">
      <div className="w-full max-w-md px-6">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 text-gaming-cyan hover:text-gaming-cyan/80 transition-colors mb-6" data-testid="link-home">
            <ArrowLeft size={20} />
            <span>Back to Home</span>
          </Link>
          
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-gaming-cyan/20 to-gaming-purple/20 rounded-xl flex items-center justify-center">
              <Shield className="text-gaming-cyan" size={32} />
            </div>
          </div>
          
          <h1 className="font-orbitron text-3xl font-bold text-gradient mb-2">ADMIN ACCESS</h1>
          <p className="text-slate-400">Enter admin password to access the tournament management panel</p>
        </div>

        {/* Login Form */}
        <Card className="card-glow border-0">
          <CardHeader className="text-center pb-4">
            <CardTitle className="font-orbitron text-gaming-cyan">SECURE LOGIN</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label className="text-sm font-semibold text-slate-300">
                  <Lock className="inline mr-2" size={16} />
                  ADMIN PASSWORD
                </Label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter admin password"
                    className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 pr-12 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20"
                    data-testid="input-admin-password"
                    disabled={loginMutation.isPending}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white"
                    data-testid="button-toggle-password"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={!password.trim() || loginMutation.isPending}
                className="w-full py-3 btn-gaming text-white font-bold text-lg rounded-xl"
                data-testid="button-admin-login"
              >
                {loginMutation.isPending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    AUTHENTICATING...
                  </>
                ) : (
                  <>
                    <Shield className="mr-2" size={20} />
                    ACCESS ADMIN PANEL
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 p-4 bg-slate-800/30 rounded-lg border border-slate-700/50">
              <div className="text-center">
                <p className="text-xs text-slate-400 mb-2">Admin Features:</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-500">
                  <div>• Review Registrations</div>
                  <div>• Approve/Reject Teams</div>
                  <div>• View Statistics</div>
                  <div>• Manage Tournament</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Notice */}
        <div className="mt-6 text-center">
          <p className="text-xs text-slate-500">
            This is a secure admin area. Unauthorized access is prohibited.
          </p>
        </div>
      </div>
    </div>
  );
}