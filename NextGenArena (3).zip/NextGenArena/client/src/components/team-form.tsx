import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Flag, User, Plus, X, Crown } from "lucide-react";
import type { TeamRegistration } from "@shared/schema";

const teamFormSchema = z.object({
  teamName: z.string().min(1, "Team name is required").max(50, "Team name too long"),
  participants: z.array(z.object({
    name: z.string().min(1, "Player name is required").max(30, "Player name too long"),
    uid: z.string().min(1, "UID is required").max(20, "UID too long"),
    email: z.string().email("Valid email is required").optional(),
    isCaptain: z.boolean().default(false),
  })).min(1, "At least one participant required").max(4, "Maximum 4 participants allowed")
    .refine(data => data.filter(p => p.isCaptain).length === 1, "Exactly one captain is required")
    .refine(data => {
      const captain = data.find(p => p.isCaptain);
      return captain && captain.email && captain.email.length > 0;
    }, "Captain must have a valid email address"),
});

type TeamFormData = z.infer<typeof teamFormSchema>;

interface TeamFormProps {
  onSubmit: (data: Omit<TeamRegistration, 'tournament' | 'level'>) => void;
  isLoading: boolean;
  tournament: string;
  level: string;
}

export default function TeamForm({ onSubmit, isLoading, tournament, level }: TeamFormProps) {
  const [participants, setParticipants] = useState([
    { name: "", uid: "", email: "", isCaptain: true }
  ]);

  const form = useForm<TeamFormData>({
    resolver: zodResolver(teamFormSchema),
    defaultValues: {
      teamName: "",
      participants: participants,
    },
  });

  const formatTournamentName = (tournament: string) => {
    return tournament === 'freefire' ? 'Free Fire' : 'PUBG Mobile';
  };

  const formatLevelName = (level: string) => {
    return level === '1st-pu' ? '1st PU' : '2nd PU';
  };

  const addParticipant = () => {
    if (participants.length < 4) {
      const newParticipants = [...participants, { name: "", uid: "", email: "", isCaptain: false }];
      setParticipants(newParticipants);
      form.setValue('participants', newParticipants);
    }
  };

  const removeParticipant = (index: number) => {
    if (participants.length > 1 && index !== 0) { // Don't allow removing captain
      const newParticipants = participants.filter((_, i) => i !== index);
      setParticipants(newParticipants);
      form.setValue('participants', newParticipants);
    }
  };

  const updateParticipant = (index: number, field: 'name' | 'uid' | 'email', value: string) => {
    const newParticipants = [...participants];
    newParticipants[index][field] = value;
    setParticipants(newParticipants);
    form.setValue('participants', newParticipants);
  };

  const handleSubmit = (data: TeamFormData) => {
    onSubmit(data);
  };

  return (
    <div className="space-y-8">
      <h2 className="text-center font-orbitron text-3xl font-bold text-gradient mb-8">
        REGISTER YOUR SQUAD
      </h2>
      
      <div className="max-w-4xl mx-auto space-y-8">
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-8">
          {/* Tournament Info */}
          <Card className="card-glow border-0">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h3 className="font-orbitron text-xl font-bold text-gaming-cyan mb-2">TOURNAMENT DETAILS</h3>
                <div className="flex justify-center space-x-8 text-sm">
                  <div className="text-center">
                    <p className="text-slate-400">Game</p>
                    <p className="font-semibold text-gaming-purple">{formatTournamentName(tournament)}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-400">Category</p>
                    <p className="font-semibold text-gaming-green">{formatLevelName(level)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Team Name */}
          <Card className="card-glow border-0">
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="font-orbitron text-xl font-bold text-gaming-cyan mb-2">TEAM INFORMATION</h3>
                  <p className="text-slate-400 text-sm">Enter your team details and squad members</p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label className="block text-sm font-semibold text-slate-300 mb-2">
                      <Flag className="inline mr-2 text-gaming-cyan" size={16} />
                      TEAM NAME
                    </Label>
                    <Input
                      placeholder="Enter your team name (e.g., Phoenix Squad)"
                      className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-2 focus:ring-gaming-cyan/20"
                      {...form.register('teamName')}
                      data-testid="input-team-name"
                    />
                    {form.formState.errors.teamName && (
                      <p className="text-red-400 text-sm mt-1">{form.formState.errors.teamName.message}</p>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Team Members */}
          <Card className="card-glow border-0">
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="font-orbitron text-xl font-bold text-gaming-purple">TEAM MEMBERS</h3>
                  <span className="text-sm text-slate-400" data-testid="text-member-count">
                    {participants.length} / 4 Players
                  </span>
                </div>

                <div className="space-y-4">
                  {participants.map((participant, index) => (
                    <div key={index} className="bg-slate-800/30 rounded-xl p-6 border border-slate-700/50">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className={`font-semibold ${index === 0 ? 'text-gaming-cyan' : 'text-slate-300'}`}>
                          <User className="inline mr-2" size={16} />
                          MEMBER #{index + 1} {index === 0 && <Crown className="inline ml-2 text-yellow-500" size={16} />}
                          {index === 0 && <span className="ml-2 text-xs">(CAPTAIN)</span>}
                        </h4>
                        {index > 0 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeParticipant(index)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                            data-testid={`button-remove-member-${index}`}
                          >
                            <X size={16} />
                          </Button>
                        )}
                        {index === 0 && (
                          <div className="w-3 h-3 bg-gaming-green rounded-full animate-pulse-glow"></div>
                        )}
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label className="block text-xs font-semibold text-slate-400 mb-2">PLAYER NAME</Label>
                          <Input
                            placeholder="Enter player name"
                            value={participant.name}
                            onChange={(e) => updateParticipant(index, 'name', e.target.value)}
                            className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-1 focus:ring-gaming-cyan/20 text-sm"
                            data-testid={`input-member-name-${index}`}
                          />
                        </div>
                        <div>
                          <Label className="block text-xs font-semibold text-slate-400 mb-2">GAME UID</Label>
                          <Input
                            placeholder="Enter unique ID"
                            value={participant.uid}
                            onChange={(e) => updateParticipant(index, 'uid', e.target.value)}
                            className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-1 focus:ring-gaming-cyan/20 text-sm"
                            data-testid={`input-member-uid-${index}`}
                          />
                        </div>
                      </div>
                      {index === 0 && (
                        <div className="mt-4">
                          <Label className="block text-xs font-semibold text-slate-400 mb-2">CAPTAIN EMAIL (REQUIRED)</Label>
                          <Input
                            type="email"
                            placeholder="Enter captain's Gmail address"
                            value={participant.email || ""}
                            onChange={(e) => updateParticipant(index, 'email', e.target.value)}
                            className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white placeholder-slate-400 focus:border-gaming-cyan focus:ring-1 focus:ring-gaming-cyan/20 text-sm"
                            data-testid={`input-member-email-${index}`}
                          />
                          <p className="text-xs text-slate-400 mt-1">Required for important tournament updates and communication</p>
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Add Member Button */}
                  {participants.length < 4 && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addParticipant}
                      className="w-full border-2 border-dashed border-slate-600 rounded-xl p-6 text-slate-400 hover:border-gaming-purple hover:text-gaming-purple transition-colors bg-transparent"
                      data-testid="button-add-member"
                    >
                      <div className="text-center">
                        <Plus className="w-6 h-6 mb-2 mx-auto group-hover:scale-110 transition-transform" />
                        <p className="font-semibold">ADD TEAM MEMBER</p>
                        <p className="text-xs">Click to add another squad member</p>
                      </div>
                    </Button>
                  )}
                </div>

                {form.formState.errors.participants && (
                  <p className="text-red-400 text-sm">{form.formState.errors.participants.message}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="text-center">
            <Button
              type="submit"
              disabled={isLoading}
              className="px-12 py-4 btn-gaming text-white font-bold text-lg rounded-xl"
              data-testid="button-register-team"
            >
              {isLoading ? "REGISTERING..." : "REGISTER TEAM"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}