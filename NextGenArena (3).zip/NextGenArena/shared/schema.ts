import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  tournament: text("tournament").notNull(), // 'freefire' or 'pubg'
  level: text("level").notNull(), // '1st-pu' or '2nd-pu'
  registrationId: text("registration_id").notNull().unique(),
  status: text("status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
});

export const participants = pgTable("participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull().references(() => teams.id),
  name: text("name").notNull(),
  uid: text("uid").notNull(),
  email: text("email"), // Only for captain
  isCaptain: integer("is_captain").notNull().default(0), // 0 = false, 1 = true
});

export const supportTickets = pgTable("support_tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("open"), // 'open', 'replied', 'closed'
  adminReply: text("admin_reply"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  repliedAt: timestamp("replied_at"),
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  registrationId: true,
  createdAt: true,
});

export const insertParticipantSchema = createInsertSchema(participants).omit({
  id: true,
});

export const teamRegistrationSchema = z.object({
  teamName: z.string().min(1, "Team name is required").max(50, "Team name too long"),
  tournament: z.enum(["freefire", "pubg"], { required_error: "Tournament selection required" }),
  level: z.enum(["1st-pu", "2nd-pu"], { required_error: "Academic level selection required" }),
  participants: z.array(z.object({
    name: z.string().min(1, "Player name is required").max(30, "Player name too long"),
    uid: z.string().min(1, "UID is required").max(20, "UID too long"),
    email: z.string().email("Valid email is required").optional(),
    isCaptain: z.boolean().default(false),
  })).min(1, "At least one participant required").max(4, "Maximum 4 participants allowed")
    .refine(data => data.filter(p => p.isCaptain).length === 1, "Exactly one captain is required")
    .refine(data => {
      const captain = data.find(p => p.isCaptain);
      return captain && captain.email && captain.email.length > 0;
    }, "Captain must have a valid email address"),
});

export const adminLoginSchema = z.object({
  password: z.string().min(1, "Password is required"),
});

export const teamReviewSchema = z.object({
  teamId: z.string().min(1, "Team ID is required"),
  action: z.enum(["approve", "reject"], { required_error: "Action is required" }),
  rejectionReason: z.string().optional(),
});

export const supportTicketSchema = z.object({
  name: z.string().min(1, "Name is required").max(50, "Name too long"),
  email: z.string().email("Valid email is required"),
  subject: z.string().min(1, "Subject is required").max(100, "Subject too long"),
  message: z.string().min(10, "Message must be at least 10 characters").max(1000, "Message too long"),
});

export const ticketReplySchema = z.object({
  ticketId: z.string().min(1, "Ticket ID is required"),
  reply: z.string().min(1, "Reply is required").max(1000, "Reply too long"),
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  createdAt: true,
});

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertParticipant = z.infer<typeof insertParticipantSchema>;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;
export type TeamRegistration = z.infer<typeof teamRegistrationSchema>;
export type AdminLogin = z.infer<typeof adminLoginSchema>;
export type TeamReview = z.infer<typeof teamReviewSchema>;
export type SupportTicketSubmission = z.infer<typeof supportTicketSchema>;
export type TicketReply = z.infer<typeof ticketReplySchema>;
export type Team = typeof teams.$inferSelect;
export type Participant = typeof participants.$inferSelect;
export type SupportTicket = typeof supportTickets.$inferSelect;

export interface TeamWithParticipants extends Team {
  participants: Participant[];
}
