import { type Team, type Participant, type SupportTicket, type InsertTeam, type InsertParticipant, type InsertSupportTicket, type TeamWithParticipants } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  getTeam(id: string): Promise<Team | undefined>;
  getTeamByRegistrationId(registrationId: string): Promise<Team | undefined>;
  getAllTeams(): Promise<Team[]>;
  getTeamsByTournament(tournament: string): Promise<Team[]>;
  getTeamsByLevel(level: string): Promise<Team[]>;
  getTeamsByStatus(status: string): Promise<Team[]>;
  updateTeamStatus(teamId: string, status: string, rejectionReason?: string): Promise<Team | undefined>;
  
  // Participant operations
  createParticipant(participant: InsertParticipant): Promise<Participant>;
  getParticipantsByTeamId(teamId: string): Promise<Participant[]>;
  
  // Combined operations
  getTeamWithParticipants(teamId: string): Promise<TeamWithParticipants | undefined>;
  getAllTeamsWithParticipants(): Promise<TeamWithParticipants[]>;
  getPendingTeamsWithParticipants(): Promise<TeamWithParticipants[]>;
  
  // Support ticket operations
  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getAllSupportTickets(): Promise<SupportTicket[]>;
  getSupportTicket(ticketId: string): Promise<SupportTicket | undefined>;
  updateTicketStatus(ticketId: string, status: string, adminReply?: string): Promise<SupportTicket | undefined>;
}

export class MemStorage implements IStorage {
  private teams: Map<string, Team>;
  private participants: Map<string, Participant>;
  private supportTickets: Map<string, SupportTicket>;

  constructor() {
    this.teams = new Map();
    this.participants = new Map();
    this.supportTickets = new Map();
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = randomUUID();
    const registrationId = this.generateRegistrationId(insertTeam.tournament);
    const team: Team = { 
      ...insertTeam, 
      id, 
      registrationId,
      status: "pending",
      rejectionReason: null,
      reviewedAt: null,
      createdAt: new Date()
    };
    this.teams.set(id, team);
    return team;
  }

  async getTeam(id: string): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async getTeamByRegistrationId(registrationId: string): Promise<Team | undefined> {
    return Array.from(this.teams.values()).find(
      (team) => team.registrationId === registrationId
    );
  }

  async getAllTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }

  async getTeamsByTournament(tournament: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(
      (team) => team.tournament === tournament
    );
  }

  async getTeamsByLevel(level: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(
      (team) => team.level === level
    );
  }

  async getTeamsByStatus(status: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(
      (team) => team.status === status
    );
  }

  async updateTeamStatus(teamId: string, status: string, rejectionReason?: string): Promise<Team | undefined> {
    const team = this.teams.get(teamId);
    if (!team) return undefined;
    
    const updatedTeam: Team = {
      ...team,
      status,
      rejectionReason: rejectionReason || null,
      reviewedAt: new Date()
    };
    
    this.teams.set(teamId, updatedTeam);
    return updatedTeam;
  }

  async createParticipant(insertParticipant: InsertParticipant): Promise<Participant> {
    const id = randomUUID();
    const participant: Participant = { 
      ...insertParticipant, 
      id,
      email: insertParticipant.email || null,
      isCaptain: insertParticipant.isCaptain ?? 0
    };
    this.participants.set(id, participant);
    return participant;
  }

  async getParticipantsByTeamId(teamId: string): Promise<Participant[]> {
    return Array.from(this.participants.values()).filter(
      (participant) => participant.teamId === teamId
    );
  }

  async getTeamWithParticipants(teamId: string): Promise<TeamWithParticipants | undefined> {
    const team = await this.getTeam(teamId);
    if (!team) return undefined;
    
    const participants = await this.getParticipantsByTeamId(teamId);
    return { ...team, participants };
  }

  async getAllTeamsWithParticipants(): Promise<TeamWithParticipants[]> {
    const teams = await this.getAllTeams();
    const teamsWithParticipants: TeamWithParticipants[] = [];
    
    for (const team of teams) {
      const participants = await this.getParticipantsByTeamId(team.id);
      teamsWithParticipants.push({ ...team, participants });
    }
    
    return teamsWithParticipants;
  }

  async getPendingTeamsWithParticipants(): Promise<TeamWithParticipants[]> {
    const pendingTeams = await this.getTeamsByStatus("pending");
    const teamsWithParticipants: TeamWithParticipants[] = [];
    
    for (const team of pendingTeams) {
      const participants = await this.getParticipantsByTeamId(team.id);
      teamsWithParticipants.push({ ...team, participants });
    }
    
    return teamsWithParticipants;
  }

  async createSupportTicket(insertTicket: InsertSupportTicket): Promise<SupportTicket> {
    const id = randomUUID();
    const ticket: SupportTicket = {
      ...insertTicket,
      id,
      status: "open",
      adminReply: null,
      repliedAt: null,
      createdAt: new Date()
    };
    this.supportTickets.set(id, ticket);
    return ticket;
  }

  async getAllSupportTickets(): Promise<SupportTicket[]> {
    return Array.from(this.supportTickets.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getSupportTicket(ticketId: string): Promise<SupportTicket | undefined> {
    return this.supportTickets.get(ticketId);
  }

  async updateTicketStatus(ticketId: string, status: string, adminReply?: string): Promise<SupportTicket | undefined> {
    const ticket = this.supportTickets.get(ticketId);
    if (!ticket) return undefined;
    
    const updatedTicket: SupportTicket = {
      ...ticket,
      status,
      adminReply: adminReply || ticket.adminReply,
      repliedAt: adminReply ? new Date() : ticket.repliedAt
    };
    
    this.supportTickets.set(ticketId, updatedTicket);
    return updatedTicket;
  }

  private generateRegistrationId(tournament: string): string {
    const prefix = tournament === 'freefire' ? 'FF' : 'PG';
    const timestamp = Date.now().toString().slice(-6);
    const counter = (this.teams.size + 1).toString().padStart(3, '0');
    return `NGA2024-${prefix}-${counter}`;
  }
}

export const storage = new MemStorage();
