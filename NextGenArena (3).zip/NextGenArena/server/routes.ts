import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { teamRegistrationSchema, adminLoginSchema, teamReviewSchema, supportTicketSchema, ticketReplySchema } from "@shared/schema";
import { z } from "zod";

const ADMIN_PASSWORD = "7204952616@5566";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register a team with participants
  app.post("/api/teams/register", async (req, res) => {
    try {
      const registrationData = teamRegistrationSchema.parse(req.body);
      
      // Create team
      const team = await storage.createTeam({
        name: registrationData.teamName,
        tournament: registrationData.tournament,
        level: registrationData.level,
      });

      // Create participants
      for (let index = 0; index < registrationData.participants.length; index++) {
        const participantData = registrationData.participants[index];
        await storage.createParticipant({
          teamId: team.id,
          name: participantData.name,
          uid: participantData.uid,
          email: participantData.email || null,
          isCaptain: participantData.isCaptain || index === 0 ? 1 : 0, // First participant is captain by default
        });
      }

      // Return team with participants
      const teamWithParticipants = await storage.getTeamWithParticipants(team.id);
      res.json(teamWithParticipants);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get all teams with participants
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getAllTeamsWithParticipants();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get team by registration ID
  app.get("/api/teams/registration/:registrationId", async (req, res) => {
    try {
      const { registrationId } = req.params;
      const team = await storage.getTeamByRegistrationId(registrationId);
      
      if (!team) {
        res.status(404).json({ message: "Team not found" });
        return;
      }

      const teamWithParticipants = await storage.getTeamWithParticipants(team.id);
      res.json(teamWithParticipants);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get teams by tournament
  app.get("/api/teams/tournament/:tournament", async (req, res) => {
    try {
      const { tournament } = req.params;
      if (!['freefire', 'pubg'].includes(tournament)) {
        res.status(400).json({ message: "Invalid tournament" });
        return;
      }

      const teams = await storage.getTeamsByTournament(tournament);
      const teamsWithParticipants = [];
      
      for (const team of teams) {
        const teamWithParticipants = await storage.getTeamWithParticipants(team.id);
        if (teamWithParticipants) {
          teamsWithParticipants.push(teamWithParticipants);
        }
      }
      
      res.json(teamsWithParticipants);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get tournament statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const allTeams = await storage.getAllTeamsWithParticipants();
      const approvedTeams = allTeams.filter(team => team.status === 'approved');
      
      const stats = {
        totalTeams: approvedTeams.length,
        totalPlayers: approvedTeams.reduce((sum, team) => sum + team.participants.length, 0),
        freeFireTeams: approvedTeams.filter(team => team.tournament === 'freefire').length,
        pubgTeams: approvedTeams.filter(team => team.tournament === 'pubg').length,
        firstPUTeams: approvedTeams.filter(team => team.level === '1st-pu').length,
        secondPUTeams: approvedTeams.filter(team => team.level === '2nd-pu').length,
        pendingTeams: allTeams.filter(team => team.status === 'pending').length,
        rejectedTeams: allTeams.filter(team => team.status === 'rejected').length,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin login
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { password } = adminLoginSchema.parse(req.body);
      
      if (password === ADMIN_PASSWORD) {
        res.json({ success: true, message: "Login successful" });
      } else {
        res.status(401).json({ success: false, message: "Invalid password" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get pending teams for admin review
  app.get("/api/admin/teams/pending", async (req, res) => {
    try {
      const pendingTeams = await storage.getPendingTeamsWithParticipants();
      res.json(pendingTeams);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all teams for admin (with status filtering)
  app.get("/api/admin/teams", async (req, res) => {
    try {
      const { status } = req.query;
      let teams;
      
      if (status && typeof status === 'string') {
        const filteredTeams = await storage.getTeamsByStatus(status);
        teams = [];
        for (const team of filteredTeams) {
          const teamWithParticipants = await storage.getTeamWithParticipants(team.id);
          if (teamWithParticipants) {
            teams.push(teamWithParticipants);
          }
        }
      } else {
        teams = await storage.getAllTeamsWithParticipants();
      }
      
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin team review (approve/reject)
  app.post("/api/admin/teams/review", async (req, res) => {
    try {
      const { teamId, action, rejectionReason } = teamReviewSchema.parse(req.body);
      
      const status = action === 'approve' ? 'approved' : 'rejected';
      const updatedTeam = await storage.updateTeamStatus(teamId, status, rejectionReason);
      
      if (!updatedTeam) {
        res.status(404).json({ message: "Team not found" });
        return;
      }
      
      const teamWithParticipants = await storage.getTeamWithParticipants(teamId);
      res.json({
        success: true,
        message: `Team ${action}d successfully`,
        team: teamWithParticipants
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Support ticket endpoints
  app.post("/api/support/tickets", async (req, res) => {
    try {
      const ticketData = supportTicketSchema.parse(req.body);
      const ticket = await storage.createSupportTicket(ticketData);
      res.json({ success: true, ticket });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get all support tickets (admin only)
  app.get("/api/admin/support/tickets", async (req, res) => {
    try {
      const tickets = await storage.getAllSupportTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Reply to support ticket (admin only)
  app.post("/api/admin/support/tickets/reply", async (req, res) => {
    try {
      const { ticketId, reply } = ticketReplySchema.parse(req.body);
      const updatedTicket = await storage.updateTicketStatus(ticketId, "replied", reply);
      
      if (!updatedTicket) {
        res.status(404).json({ message: "Ticket not found" });
        return;
      }
      
      res.json({ success: true, ticket: updatedTicket });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Close support ticket (admin only)
  app.post("/api/admin/support/tickets/:ticketId/close", async (req, res) => {
    try {
      const { ticketId } = req.params;
      const updatedTicket = await storage.updateTicketStatus(ticketId, "closed");
      
      if (!updatedTicket) {
        res.status(404).json({ message: "Ticket not found" });
        return;
      }
      
      res.json({ success: true, ticket: updatedTicket });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
